/**
 * Centralized error handler (CWE-200 + CWE-209 remediation).
 *
 * - Client responses are sanitized: a generic message plus a correlation id.
 *   The raw stack, internal file paths and library versions never leave the
 *   server.
 * - The full error is logged server-side only.
 * - Debug headers (X-Debug, X-Stack, X-Error, X-Debug-Host) are emitted ONLY in
 *   development; in every other environment they are stripped from the response.
 */

interface ErrorRequest {
  id?: string;
}

interface DebugCapableResponse {
  status(code: number): DebugCapableResponse;
  json(body: unknown): void;
  setHeader(name: string, value: string): void;
  removeHeader(name: string): void;
}

const DEBUG_HEADERS = ["X-Debug", "X-Stack", "X-Error", "X-Debug-Host"] as const;

const env =
  (import.meta as unknown as {
    env?: Record<string, string | boolean | undefined>;
  }).env ?? {};

const isDevelopment = env.DEV === true || env.NODE_ENV === "development";

function generateRequestId(): string {
  const c = globalThis.crypto;
  if (c && typeof c.randomUUID === "function") return c.randomUUID();
  return `req_${Date.now().toString(36)}`;
}

/** Server-side structured logging — never serialized back to the client. */
function logError(err: unknown, requestId: string): void {
  console.error({ level: "error", requestId, err });
}

export function errorHandler(
  err: unknown,
  req: ErrorRequest,
  res: DebugCapableResponse,
): void {
  const requestId = req.id ?? generateRequestId();

  // Full detail stays on the server.
  logError(err, requestId);

  // Strip any debug headers that upstream code may have set, in all non-dev modes.
  if (!isDevelopment) {
    for (const header of DEBUG_HEADERS) {
      res.removeHeader(header);
    }
  }

  // Sanitized, zero-leak client payload.
  res.status(500).json({ error: "Internal Server Error", requestId });

  // Debug headers are permitted strictly in development.
  if (isDevelopment) {
    const message = err instanceof Error ? err.message : "Unknown error";
    res.setHeader("X-Debug", message);
  }
}

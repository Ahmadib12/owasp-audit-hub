/**
 * Server-side authentication & authorization middleware (CWE-287 remediation).
 *
 * Roles are resolved ONLY from the verified session attached to the request by
 * an upstream authenticator. Client-supplied headers such as `x-role` are never
 * trusted. These handlers are dependency-free structural middleware so they can
 * be composed on any `/admin/*` route.
 */

export interface AuthUser {
  id: string;
  role: string;
}

export interface AuthedRequest {
  /** Populated by the session/JWT verifier upstream. Never trust the client. */
  user?: AuthUser;
}

export interface AuthResponse {
  status(code: number): AuthResponse;
  json(body: unknown): void;
  end(): void;
}

export type NextFunction = () => void;

export type AuthHandler = (
  req: AuthedRequest,
  res: AuthResponse,
  next: NextFunction,
) => void;

/** Rejects any request without a verified session with 401 Unauthorized. */
export const requireAuth: AuthHandler = (req, res, next) => {
  if (!req.user || !req.user.id) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }
  next();
};

/**
 * Returns a guard that enforces a specific role from the verified session.
 * 401 when unauthenticated, 403 Forbidden when the role does not match.
 */
export const requireRole = (role: string): AuthHandler => (req, res, next) => {
  if (!req.user || !req.user.id) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }
  if (req.user.role !== role) {
    res.status(403).json({ error: "Forbidden" });
    return;
  }
  next();
};

/**
 * Hardened outbound TLS client (CWE-295 remediation).
 *
 * `rejectUnauthorized` is true by default. Certificate verification may only be
 * relaxed when BOTH `ALLOW_INSECURE_TLS === "true"` AND the runtime is NOT
 * production. Whenever insecure mode is active a loud warning is emitted.
 */

const env =
  (import.meta as unknown as {
    env?: Record<string, string | boolean | undefined>;
  }).env ?? {};

const isProduction = env.PROD === true || env.NODE_ENV === "production";
const allowInsecureOverride = env.ALLOW_INSECURE_TLS === "true";

/** Secure by default; insecure only under the explicit non-production override. */
export const rejectUnauthorized: boolean = !(
  allowInsecureOverride && !isProduction
);

if (!rejectUnauthorized) {
  console.warn(
    "[apiClient] TLS certificate verification is DISABLED (insecure mode). " +
      "Never allow this in production.",
  );
}

export interface TlsAgentOptions {
  rejectUnauthorized: boolean;
  ca?: string;
}

/** Options handed to the underlying HTTPS agent for every API call. */
export const tlsAgentOptions: TlsAgentOptions = {
  rejectUnauthorized,
  ca: typeof env.INTERNAL_CA_BUNDLE === "string" ? env.INTERNAL_CA_BUNDLE : undefined,
};

export function createApiClient(baseUrl: string): {
  baseUrl: string;
  tls: TlsAgentOptions;
} {
  return { baseUrl, tls: tlsAgentOptions };
}

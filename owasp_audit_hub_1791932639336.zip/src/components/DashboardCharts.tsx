import { motion } from "framer-motion";
import {
  AlertTriangle,
  CheckCircle2,
  Clock,
  TrendingUp,
} from "lucide-react";
import {
  Bar,
  BarChart,
  Cell,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { CATEGORY_META } from "../constants";
import type { AuditResult, FindingCategory, Severity } from "../types";

interface DashboardChartsProps {
  result: AuditResult;
  severityFilter: Severity | "all";
  onFilter: (s: Severity | "all") => void;
}

const SEVERITY_COLORS: Record<Severity, string> = {
  critical: "#f43f5e",
  high: "#fb923c",
  medium: "#f59e0b",
  low: "#38bdf8",
  passed: "#10b981",
};

export default function DashboardCharts({
  result,
  severityFilter,
  onFilter,
}: DashboardChartsProps) {
  const donutData = [
    { name: "Critical", value: result.critical, color: SEVERITY_COLORS.critical },
    { name: "High", value: result.high, color: SEVERITY_COLORS.high },
    { name: "Medium", value: result.medium, color: SEVERITY_COLORS.medium },
    { name: "Low", value: result.low, color: SEVERITY_COLORS.low },
    { name: "Passed", value: result.passed, color: SEVERITY_COLORS.passed },
  ];

  const barData = result.categoryCounts.map((c) => ({
    name: CATEGORY_META[c.category],
    count: c.count,
  }));

  const scoreAngle = (result.score / 100) * 360;
  const scoreColor =
    result.score >= 80 ? "#10b981" : result.score >= 55 ? "#f59e0b" : "#f43f5e";

  const filters: (Severity | "all")[] = [
    "all",
    "critical",
    "high",
    "medium",
    "low",
    "passed",
  ];

  return (
    <div className="space-y-5">
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {/* Score gauge */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.35 }}
          className="rounded-2xl border border-border bg-card p-5"
        >
          <div className="flex items-center gap-2 text-muted-foreground">
            <TrendingUp className="h-4 w-4" strokeWidth={1.5} />
            <p className="text-xs font-medium uppercase tracking-wide">
              Security score
            </p>
          </div>
          <div className="relative mx-auto mt-3 h-32 w-32">
            <svg viewBox="0 0 100 100" className="h-full w-full -rotate-90">
              <circle
                cx="50"
                cy="50"
                r="42"
                fill="none"
                stroke="currentColor"
                strokeWidth="10"
                className="text-muted/50"
              />
              <circle
                cx="50"
                cy="50"
                r="42"
                fill="none"
                stroke={scoreColor}
                strokeWidth="10"
                strokeLinecap="round"
                strokeDasharray={`${scoreAngle} 360`}
              />
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <p className="text-3xl font-bold tracking-tight">{result.score}</p>
              <p className="text-[10px] uppercase tracking-wide text-muted-foreground">
                / 100
              </p>
            </div>
          </div>
          <p className="mt-2 text-center text-xs text-muted-foreground">
            {result.score >= 80
              ? "Strong posture"
              : result.score >= 55
                ? "Needs hardening"
                : "High risk detected"}
          </p>
        </motion.div>

        {/* Pass summary cards */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.35, delay: 0.05 }}
          className="rounded-2xl border border-emerald-500/20 bg-emerald-500/5 p-5"
        >
          <div className="flex items-center gap-2 text-emerald-400">
            <CheckCircle2 className="h-4 w-4" strokeWidth={1.5} />
            <p className="text-xs font-medium uppercase tracking-wide">
              Passed checks
            </p>
          </div>
          <p className="mt-3 text-3xl font-bold text-emerald-400">{result.passed}</p>
          <p className="mt-1 text-xs text-muted-foreground">Checks green</p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.35, delay: 0.1 }}
          className="rounded-2xl border border-amber-500/20 bg-amber-500/5 p-5"
        >
          <div className="flex items-center gap-2 text-amber-400">
            <AlertTriangle className="h-4 w-4" strokeWidth={1.5} />
            <p className="text-xs font-medium uppercase tracking-wide">
              Warnings
            </p>
          </div>
          <p className="mt-3 text-3xl font-bold text-amber-400">
            {result.medium + result.low}
          </p>
          <p className="mt-1 text-xs text-muted-foreground">Medium + low</p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.35, delay: 0.15 }}
          className="rounded-2xl border border-rose-500/20 bg-rose-500/5 p-5"
        >
          <div className="flex items-center gap-2 text-rose-400">
            <AlertTriangle className="h-4 w-4" strokeWidth={1.5} />
            <p className="text-xs font-medium uppercase tracking-wide">
              Findings
            </p>
          </div>
          <p className="mt-3 text-3xl font-bold text-rose-400">
            {result.critical + result.high}
          </p>
          <p className="mt-1 text-xs text-muted-foreground">Critical + high</p>
        </motion.div>
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        {/* Severity donut */}
        <div className="rounded-2xl border border-border bg-card p-5">
          <p className="text-sm font-semibold">Findings by severity</p>
          <div className="mt-3 flex items-center gap-2">
            {filters.map((f) => (
              <button
                key={f}
                onClick={() => onFilter(f)}
                className={`rounded-full px-3 py-1 text-xs font-medium capitalize transition-colors ${
                  severityFilter === f
                    ? "bg-emerald-500 text-emerald-950"
                    : "bg-muted text-muted-foreground hover:bg-accent"
                }`}
              >
                {f}
              </button>
            ))}
          </div>
          <div className="h-56">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={donutData}
                  cx="50%"
                  cy="50%"
                  innerRadius={55}
                  outerRadius={80}
                  paddingAngle={3}
                  dataKey="value"
                >
                  {donutData.map((entry) => (
                    <Cell key={entry.name} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{
                    background: "var(--popover)",
                    border: "1px solid var(--border)",
                    borderRadius: "0.75rem",
                    fontSize: "0.75rem",
                  }}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="mt-2 flex flex-wrap justify-center gap-x-3 gap-y-1">
            {donutData.map((d) => (
              <span key={d.name} className="flex items-center gap-1.5 text-xs text-muted-foreground">
                <span className="h-2 w-2 rounded-full" style={{ background: d.color }} />
                {d.name} ({d.value})
              </span>
            ))}
          </div>
        </div>

        {/* Category bar */}
        <div className="rounded-2xl border border-border bg-card p-5">
          <p className="text-sm font-semibold">By vulnerability category</p>
          <div className="mt-3 h-56">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={barData}>
                <XAxis
                  dataKey="name"
                  tick={{ fontSize: 11, fill: "var(--muted-foreground)" }}
                  axisLine={false}
                  tickLine={false}
                />
                <YAxis
                  allowDecimals={false}
                  tick={{ fontSize: 11, fill: "var(--muted-foreground)" }}
                  axisLine={false}
                  tickLine={false}
                  width={24}
                />
                <Tooltip
                  cursor={{ fill: "var(--accent)", opacity: 0.3 }}
                  contentStyle={{
                    background: "var(--popover)",
                    border: "1px solid var(--border)",
                    borderRadius: "0.75rem",
                    fontSize: "0.75rem",
                  }}
                />
                <Bar dataKey="count" fill="#38bdf8" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      <div className="rounded-2xl border border-border bg-card p-5">
        <div className="flex items-center justify-between">
          <p className="text-sm font-semibold">Scan score trend</p>
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <Clock className="h-3.5 w-3.5" strokeWidth={1.5} />
            Avg remediation {result.avgRemediationDays} days
          </div>
        </div>
        <div className="mt-3 h-32">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={result.trend}>
              <XAxis
                dataKey="label"
                tick={{ fontSize: 11, fill: "var(--muted-foreground)" }}
                axisLine={false}
                tickLine={false}
              />
              <YAxis
                domain={[0, 100]}
                tick={{ fontSize: 11, fill: "var(--muted-foreground)" }}
                axisLine={false}
                tickLine={false}
                width={30}
              />
              <Tooltip
                cursor={{ fill: "var(--accent)", opacity: 0.3 }}
                contentStyle={{
                  background: "var(--popover)",
                  border: "1px solid var(--border)",
                  borderRadius: "0.75rem",
                  fontSize: "0.75rem",
                }}
              />
              <Bar dataKey="score" fill="#10b981" radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}
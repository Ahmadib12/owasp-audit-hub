import { useState } from "react";
import {
  Bell,
  History,
  LogOut,
  Moon,
  ShieldCheck,
  Sun,
  User,
  X,
} from "lucide-react";
import type { UserProfile } from "../types";

interface NavbarProps {
  user: UserProfile | null;
  dark: boolean;
  onToggleTheme: () => void;
  onOpenAuth: () => void;
  onOpenHistory: () => void;
  onOpenOwasp: () => void;
  onLogout: () => void;
  currentTarget: string;
  historyCount: number;
}

export default function Navbar({
  user,
  dark,
  onToggleTheme,
  onOpenAuth,
  onOpenHistory,
  onOpenOwasp,
  onLogout,
  currentTarget,
  historyCount,
}: NavbarProps) {
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <header className="sticky top-0 z-40 border-b border-border bg-background/80 backdrop-blur-xl">
      <div className="mx-auto flex h-16 max-w-7xl items-center gap-3 px-4 sm:px-6">
        <div className="flex items-center gap-2.5">
          <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-emerald-500/15 text-emerald-400 ring-1 ring-emerald-500/30">
            <ShieldCheck className="h-5 w-5" strokeWidth={1.5} />
          </div>
          <div className="leading-none">
            <p className="text-sm font-semibold tracking-tight">CyberAudit</p>
            <p className="text-[10px] font-medium uppercase tracking-[0.14em] text-emerald-400">
              Pro Scanner
            </p>
          </div>
        </div>

        <nav className="ml-6 hidden items-center gap-1 md:flex">
          <button
            onClick={onOpenOwasp}
            className="rounded-lg px-3 py-2 text-sm font-medium text-muted-foreground transition-colors hover:bg-accent hover:text-foreground"
          >
            OWASP Top 10
          </button>
          <div className="ml-2 hidden max-w-[220px] items-center gap-1.5 truncate rounded-full border border-border bg-muted/50 px-3 py-1 text-xs text-muted-foreground lg:flex">
            <span className="h-1.5 w-1.5 shrink-0 rounded-full bg-emerald-400" />
            <span className="truncate">{currentTarget || "No target"}</span>
          </div>
        </nav>

        <div className="ml-auto flex items-center gap-1.5">
          <button
            onClick={onOpenHistory}
            className="relative flex h-9 w-9 items-center justify-center rounded-lg text-muted-foreground transition-colors hover:bg-accent hover:text-foreground"
            title="Scan history"
          >
            <History className="h-[1.1rem] w-[1.1rem]" strokeWidth={1.5} />
            {historyCount > 0 && (
              <span className="absolute -right-0.5 -top-0.5 flex h-4 min-w-4 items-center justify-center rounded-full bg-emerald-500 px-1 text-[10px] font-semibold text-emerald-950">
                {historyCount}
              </span>
            )}
          </button>
          <button
            className="flex h-9 w-9 items-center justify-center rounded-lg text-muted-foreground transition-colors hover:bg-accent hover:text-foreground"
            title="Notifications"
          >
            <Bell className="h-[1.1rem] w-[1.1rem]" strokeWidth={1.5} />
          </button>
          <button
            onClick={onToggleTheme}
            className="flex h-9 w-9 items-center justify-center rounded-lg text-muted-foreground transition-colors hover:bg-accent hover:text-foreground"
            title="Toggle theme"
          >
            {dark ? (
              <Sun className="h-[1.1rem] w-[1.1rem]" strokeWidth={1.5} />
            ) : (
              <Moon className="h-[1.1rem] w-[1.1rem]" strokeWidth={1.5} />
            )}
          </button>

          {user ? (
            <div className="relative ml-1">
              <button
                onClick={() => setMenuOpen((v) => !v)}
                className="flex items-center gap-2 rounded-lg px-2 py-1.5 transition-colors hover:bg-accent"
              >
                <div className="flex h-8 w-8 items-center justify-center rounded-full bg-emerald-500/15 text-sm font-semibold text-emerald-400 ring-1 ring-emerald-500/30">
                  {user.name.charAt(0).toUpperCase()}
                </div>
                <div className="hidden text-left leading-tight sm:block">
                  <p className="max-w-[110px] truncate text-xs font-semibold">
                    {user.name}
                  </p>
                  <p className="text-[10px] text-muted-foreground">{user.role}</p>
                </div>
              </button>
              {menuOpen && (
                <>
                  <div
                    className="fixed inset-0 z-10"
                    onClick={() => setMenuOpen(false)}
                  />
                  <div className="absolute right-0 z-20 mt-2 w-56 overflow-hidden rounded-xl border border-border bg-popover p-1 shadow-xl">
                    <button
                      onClick={onLogout}
                      className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-sm text-rose-400 transition-colors hover:bg-rose-500/10"
                    >
                      <LogOut className="h-4 w-4" strokeWidth={1.5} />
                      Sign out
                    </button>
                  </div>
                </>
              )}
            </div>
          ) : (
            <button
              onClick={onOpenAuth}
              className="ml-1 inline-flex items-center gap-1.5 rounded-lg bg-emerald-500 px-3 py-2 text-sm font-medium text-emerald-950 transition-all hover:bg-emerald-400 active:scale-[0.98]"
            >
              <User className="h-4 w-4" strokeWidth={1.5} />
              Sign in
            </button>
          )}
        </div>
      </div>
    </header>
  );
}
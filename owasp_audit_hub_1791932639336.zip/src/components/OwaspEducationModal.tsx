import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import {
  AlertTriangle,
  CheckSquare,
  ClipboardCopy,
  GraduationCap,
  Lock,
  X,
} from "lucide-react";
import { OWASP_ITEMS } from "../constants";

interface OwaspEducationModalProps {
  open: boolean;
  onClose: () => void;
}

export default function OwaspEducationModal({
  open,
  onClose,
}: OwaspEducationModalProps) {
  const [selected, setSelected] = useState(OWASP_ITEMS[0].code);
  const [copied, setCopied] = useState<string | null>(null);
  const item = OWASP_ITEMS.find((o) => o.code === selected) ?? OWASP_ITEMS[0];

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    if (open) window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onClose]);

  if (!open) return null;

  const copyTemplate = async () => {
    try {
      await navigator.clipboard.writeText(item.remediationTemplate);
      setCopied(item.code);
      setTimeout(() => setCopied(null), 1500);
    } catch {
      /* blocked */
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div
        className="absolute inset-0 bg-black/60 backdrop-blur-sm"
        onClick={onClose}
      />
      <motion.div
        initial={{ opacity: 0, scale: 0.96, y: 16 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.96 }}
        transition={{ type: "spring", stiffness: 300, damping: 28 }}
        className="relative z-10 flex max-h-[90vh] w-full max-w-5xl flex-col overflow-hidden rounded-2xl border border-border bg-popover shadow-2xl"
      >
        <div className="flex items-center justify-between border-b border-border px-5 py-4">
          <div className="flex items-center gap-2.5">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-emerald-500/15 text-emerald-400 ring-1 ring-emerald-500/30">
              <GraduationCap className="h-5 w-5" strokeWidth={1.5} />
            </div>
            <div>
              <p className="text-sm font-semibold">OWASP Top 10 for SMEs</p>
              <p className="text-xs text-muted-foreground">
                Interactive security playbook for small teams
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="flex h-9 w-9 items-center justify-center rounded-lg text-muted-foreground transition-colors hover:bg-accent"
            title="Close"
          >
            <X className="h-5 w-5" strokeWidth={1.5} />
          </button>
        </div>

        <div className="flex flex-1 flex-col overflow-hidden md:flex-row">
          {/* Sidebar */}
          <div className="flex shrink-0 flex-col gap-1 overflow-y-auto border-b border-border p-3 md:w-64 md:border-b-0 md:border-r">
            {OWASP_ITEMS.map((o) => (
              <button
                key={o.code}
                onClick={() => setSelected(o.code)}
                className={`flex items-center gap-2 rounded-lg px-3 py-2 text-left text-xs transition-colors ${
                  selected === o.code
                    ? "bg-emerald-500/10 text-emerald-400 ring-1 ring-emerald-500/30"
                    : "text-muted-foreground hover:bg-accent hover:text-foreground"
                }`}
              >
                <span className="font-mono">{o.code}</span>
                <span className="line-clamp-1">{o.title}</span>
              </button>
            ))}
          </div>

          {/* Detail */}
          <div className="flex-1 overflow-y-auto p-5">
            <div className="mb-1 flex items-center gap-2">
              <span className="rounded-lg bg-emerald-500/10 px-2.5 py-1 font-mono text-xs font-semibold text-emerald-400 ring-1 ring-emerald-500/30">
                {item.code}
              </span>
              <h3 className="text-lg font-semibold">{item.title}</h3>
            </div>
            <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
              {item.summary}
            </p>

            <div className="mt-4 grid gap-3 md:grid-cols-2">
              <div className="rounded-xl border border-rose-500/20 bg-rose-500/5 p-4">
                <div className="flex items-center gap-2 text-rose-400">
                  <AlertTriangle className="h-4 w-4" strokeWidth={1.5} />
                  <p className="text-xs font-semibold uppercase tracking-wide">
                    Attack scenario
                  </p>
                </div>
                <p className="mt-2 text-sm leading-relaxed">
                  {item.attackScenario}
                </p>
              </div>
              <div className="rounded-xl border border-amber-500/20 bg-amber-500/5 p-4">
                <div className="flex items-center gap-2 text-amber-400">
                  <Lock className="h-4 w-4" strokeWidth={1.5} />
                  <p className="text-xs font-semibold uppercase tracking-wide">
                    Impact & SME risk
                  </p>
                </div>
                <p className="mt-2 text-sm leading-relaxed">{item.impact}</p>
                <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                  {item.smeRisk}
                </p>
              </div>
            </div>

            <div className="mt-4 rounded-xl border border-border bg-muted/30 p-4">
              <div className="flex items-center gap-2 text-emerald-400">
                <CheckSquare className="h-4 w-4" strokeWidth={1.5} />
                <p className="text-xs font-semibold uppercase tracking-wide">
                  Remediation checklist
                </p>
              </div>
              <ul className="mt-2 space-y-1.5">
                {item.checklist.map((c, i) => (
                  <li key={i} className="flex items-start gap-2 text-sm">
                    <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-emerald-400" />
                    {c}
                  </li>
                ))}
              </ul>
            </div>

            <div className="mt-4">
              <div className="mb-2 flex items-center justify-between">
                <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                  Config template
                </p>
                <button
                  onClick={copyTemplate}
                  className="inline-flex items-center gap-1.5 rounded-lg border border-border bg-card px-3 py-1.5 text-xs font-medium transition-colors hover:border-emerald-500/40"
                >
                  <ClipboardCopy className="h-3.5 w-3.5" strokeWidth={1.5} />
                  {copied === item.code ? "Copied!" : "Copy"}
                </button>
              </div>
              <pre className="overflow-x-auto rounded-xl border border-border bg-background p-3 font-mono text-xs leading-relaxed">
                {item.remediationTemplate}
              </pre>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
import { useMemo, useState } from "react";
import { motion } from "framer-motion";
import {
  ChevronDown,
  Copy,
  Download,
  ExternalLink,
  FileCode2,
  Folders,
  Search,
} from "lucide-react";
import {
  buildBanditJson,
  buildSemgrepJson,
  CATEGORY_META,
  SEVERITY_META,
} from "../constants";
import type { AuditResult, FindingCategory, Severity } from "../types";

interface FindingsListProps {
  result: AuditResult;
}

function downloadJson(filename: string, data: object) {
  const blob = new Blob([JSON.stringify(data, null, 2)], {
    type: "application/json",
  });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

export default function FindingsList({ result }: FindingsListProps) {
  const [severity, setSeverity] = useState<Severity | "all">("all");
  const [category, setCategory] = useState<FindingCategory | "all">("all");
  const [query, setQuery] = useState("");
  const [expanded, setExpanded] = useState<string | null>(null);
  const [copied, setCopied] = useState<string | null>(null);

  const categories = useMemo(() => {
    const set = new Set<FindingCategory>();
    result.findings.forEach((f) => set.add(f.category));
    return Array.from(set);
  }, [result]);

  const filtered = useMemo(
    () =>
      result.findings.filter((f) => {
        if (severity !== "all" && f.severity !== severity) return false;
        if (category !== "all" && f.category !== category) return false;
        if (query) {
          const q = query.toLowerCase();
          return (
            f.title.toLowerCase().includes(q) ||
            f.cweId.toLowerCase().includes(q) ||
            f.file.toLowerCase().includes(q)
          );
        }
        return true;
      }),
    [result, severity, category, query],
  );

  const copy = async (text: string, id: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(id);
      setTimeout(() => setCopied(null), 1500);
    } catch {
      /* clipboard blocked */
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-col gap-3 rounded-2xl border border-border bg-card p-4 sm:flex-row sm:items-center">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search CWE, path, title..."
            className="w-full rounded-xl border border-border bg-background py-2.5 pl-10 pr-3 text-sm outline-none transition-colors focus:ring-2 focus:ring-emerald-500/40"
          />
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <select
            value={severity}
            onChange={(e) => setSeverity(e.target.value as Severity | "all")}
            className="rounded-xl border border-border bg-background px-3 py-2.5 text-sm outline-none transition-colors focus:ring-2 focus:ring-emerald-500/40"
          >
            <option value="all">All severities</option>
            <option value="critical">Critical</option>
            <option value="high">High</option>
            <option value="medium">Medium</option>
            <option value="low">Low</option>
          </select>
          <select
            value={category}
            onChange={(e) =>
              setCategory(e.target.value as FindingCategory | "all")
            }
            className="rounded-xl border border-border bg-background px-3 py-2.5 text-sm outline-none transition-colors focus:ring-2 focus:ring-emerald-500/40"
          >
            <option value="all">All categories</option>
            {categories.map((c) => (
              <option key={c} value={c}>
                {CATEGORY_META[c]}
              </option>
            ))}
          </select>
        </div>
      </div>

      <div className="flex flex-wrap items-center justify-between gap-3">
        <p className="text-sm font-semibold">
          {filtered.length} finding{filtered.length === 1 ? "" : "s"}
        </p>
        <div className="flex gap-2">
          <button
            onClick={() =>
              downloadJson(
                `${result.targetUrl.replace(/^https?:\/\//, "").replace(/[^a-z0-9]/gi, "_")}-semgrep.json`,
                buildSemgrepJson(result.targetUrl, result.findings),
              )
            }
            className="inline-flex items-center gap-1.5 rounded-lg border border-border bg-card px-3 py-2 text-xs font-medium text-foreground transition-colors hover:border-emerald-500/40"
          >
            <Download className="h-3.5 w-3.5" strokeWidth={1.5} />
            semgrep.json
          </button>
          <button
            onClick={() =>
              downloadJson(
                `${result.targetUrl.replace(/^https?:\/\//, "").replace(/[^a-z0-9]/gi, "_")}-bandit.json`,
                buildBanditJson(result.targetUrl, result.findings),
              )
            }
            className="inline-flex items-center gap-1.5 rounded-lg border border-border bg-card px-3 py-2 text-xs font-medium text-foreground transition-colors hover:border-emerald-500/40"
          >
            <Download className="h-3.5 w-3.5" strokeWidth={1.5} />
            bandit.json
          </button>
        </div>
      </div>

      {filtered.length === 0 ? (
        <div className="flex flex-col items-center justify-center rounded-2xl border border-dashed border-border py-16 text-center">
          <Folders className="mb-3 h-8 w-8 text-muted-foreground" strokeWidth={1.5} />
          <p className="text-sm font-medium">No findings match these filters</p>
          <p className="mt-1 text-xs text-muted-foreground">
            Adjust severity, category or search terms.
          </p>
        </div>
      ) : (
        <div className="space-y-3">
          {filtered.map((f) => {
            const meta = SEVERITY_META[f.severity];
            const isOpen = expanded === f.id;
            return (
              <motion.div
                key={f.id}
                layout
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                className={`overflow-hidden rounded-2xl border bg-card transition-colors ${meta.border}`}
              >
                <button
                  onClick={() => setExpanded(isOpen ? null : f.id)}
                  className="flex w-full items-center gap-3 p-4 text-left"
                >
                  <span
                    className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-xl ${meta.bg}`}
                  >
                    <FileCode2
                      className="h-5 w-5"
                      style={{ color: meta.color }}
                      strokeWidth={1.5}
                    />
                  </span>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-semibold">{f.title}</p>
                    <div className="mt-1 flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-muted-foreground">
                      <span style={{ color: meta.color }}>{f.cweId}</span>
                      <span className="capitalize">
                        {CATEGORY_META[f.category]}
                      </span>
                      <span className="font-mono">
                        {f.file}:{f.line}
                      </span>
                      <span className="capitalize">{f.detectedBy}</span>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <span
                      className={`rounded-full px-2.5 py-1 text-[10px] font-semibold uppercase ${meta.bg}`}
                      style={{ color: meta.color }}
                    >
                      {meta.label}
                    </span>
                    <ChevronDown
                      className={`h-4 w-4 text-muted-foreground transition-transform ${
                        isOpen ? "rotate-180" : ""
                      }`}
                    />
                  </div>
                </button>

                {isOpen && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: "auto" }}
                    className="border-t border-border"
                  >
                    <div className="space-y-4 p-4">
                      <div>
                        <p className="mb-1 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                          Description
                        </p>
                        <p className="text-sm leading-relaxed">{f.description}</p>
                        <p className="mt-2 text-xs font-semibold uppercase tracking-wide text-rose-400">
                          Impact: <span className="font-normal text-foreground">{f.impact}</span>
                        </p>
                      </div>

                      <div className="grid gap-3 md:grid-cols-2">
                        <div>
                          <div className="mb-1.5 flex items-center justify-between">
                            <p className="text-xs font-semibold uppercase tracking-wide text-rose-400">
                              Vulnerable
                            </p>
                            <button
                              onClick={() => copy(f.code.vulnerable, `v-${f.id}`)}
                              className="text-muted-foreground hover:text-foreground"
                              title="Copy"
                            >
                              <Copy className="h-3.5 w-3.5" strokeWidth={1.5} />
                            </button>
                          </div>
                          <pre className="overflow-x-auto rounded-xl border border-rose-500/30 bg-rose-500/5 p-3 font-mono text-xs leading-relaxed">
                            {f.code.vulnerable}
                          </pre>
                        </div>
                        <div>
                          <div className="mb-1.5 flex items-center justify-between">
                            <p className="text-xs font-semibold uppercase tracking-wide text-emerald-400">
                              Secure fix
                            </p>
                            <button
                              onClick={() => copy(f.code.secure, `s-${f.id}`)}
                              className="text-muted-foreground hover:text-foreground"
                              title="Copy"
                            >
                              <Copy className="h-3.5 w-3.5" strokeWidth={1.5} />
                            </button>
                          </div>
                          <pre className="overflow-x-auto rounded-xl border border-emerald-500/30 bg-emerald-500/5 p-3 font-mono text-xs leading-relaxed">
                            {f.code.secure}
                          </pre>
                        </div>
                      </div>
                      <p className="text-xs text-muted-foreground">
                        {f.code.explanation}
                      </p>

                      <div>
                        <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                          Remediation steps
                        </p>
                        <ol className="list-decimal space-y-1 pl-5 text-sm">
                          {f.remediationSteps.map((s, i) => (
                            <li key={i} className="leading-relaxed">
                              {s}
                            </li>
                          ))}
                        </ol>
                      </div>

                      <div className="flex flex-wrap gap-2">
                        {f.references.map((r) => (
                          <a
                            key={r.url}
                            href={r.url}
                            target="_blank"
                            rel="noreferrer"
                            className="inline-flex items-center gap-1.5 rounded-lg border border-border bg-muted/40 px-3 py-1.5 text-xs font-medium text-foreground transition-colors hover:border-emerald-500/40"
                          >
                            {r.label}
                            <ExternalLink
                              className="h-3 w-3 text-muted-foreground"
                              strokeWidth={1.5}
                            />
                          </a>
                        ))}
                      </div>
                    </div>
                  </motion.div>
                )}
              </motion.div>
            );
          })}
        </div>
      )}
    </div>
  );
}
import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { ArrowRight, CheckCircle2, Loader2, Rocket, X } from "lucide-react";
import { SCAN_STEPS } from "../constants";
import { PRESET_TARGETS } from "../types";
import type { ScanStep } from "../types";

const URL_PATTERN = "https?://.+";

interface ScanFormProps {
  scanning: boolean;
  options: Record<string, boolean>;
  onToggleOption: (key: string) => void;
  onScan: (url: string) => void;
  onReset: () => void;
}

const OPTION_CONFIG = [
  { key: "semgrep", label: "Semgrep SAST", detail: "Static analysis rules" },
  { key: "bandit", label: "Bandit", detail: "Python heuristics" },
  { key: "ssl", label: "TLS / SSL", detail: "Handshake checks" },
  { key: "headers", label: "Headers", detail: "CSP, HSTS, etc." },
];

export default function ScanForm({
  scanning,
  options,
  onToggleOption,
  onScan,
  onReset,
}: ScanFormProps) {
  const [url, setUrl] = useState("https://shop.example.com");
  const [error, setError] = useState("");
  const [stepIndex, setStepIndex] = useState(0);

  useEffect(() => {
    if (!scanning) return;
    setStepIndex(0);
    let i = 0;
    const id = window.setInterval(() => {
      i += 1;
      setStepIndex(i);
      if (i >= SCAN_STEPS.length) window.clearInterval(id);
    }, 650);
    return () => window.clearInterval(id);
  }, [scanning]);

  const validate = (value: string): boolean =>
    new RegExp(`^${URL_PATTERN}$`).test(value.trim());

  const handleSubmit = () => {
    if (!validate(url)) {
      setError("Enter a valid URL starting with http:// or https://");
      return;
    }
    setError("");
    onScan(url.trim());
  };

  const steps: ScanStep[] = SCAN_STEPS.map((s, idx) => ({
    ...s,
    active: scanning && idx === stepIndex,
    done: scanning ? idx < stepIndex : false,
  }));

  return (
    <section className="mx-auto w-full max-w-3xl px-4 sm:px-6">
      <motion.div
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
        className="overflow-hidden rounded-2xl border border-border bg-card shadow-lg shadow-black/5"
      >
        <div className="border-b border-border bg-muted/30 px-5 py-3">
          <div className="flex items-center gap-2">
            <div className="flex gap-1.5">
              <span className="h-2.5 w-2.5 rounded-full bg-rose-400/70" />
              <span className="h-2.5 w-2.5 rounded-full bg-amber-400/70" />
              <span className="h-2.5 w-2.5 rounded-full bg-emerald-400/70" />
            </div>
            <p className="ml-2 text-xs font-medium text-muted-foreground">
              Target scanner
            </p>
          </div>
        </div>

        <div className="space-y-4 p-5 sm:p-6">
          <div>
            <label className="mb-1.5 block text-sm font-medium">
              Website URL
            </label>
            <div className="flex flex-col gap-2 sm:flex-row">
              <div className="relative flex-1">
                <input
                  type="url"
                  value={url}
                  onChange={(e) => {
                    setUrl(e.target.value);
                    if (error) setError("");
                  }}
                  placeholder="https://example.com"
                  pattern={URL_PATTERN}
                  inputMode="url"
                  disabled={scanning}
                  className={`w-full rounded-xl border bg-background px-4 py-3 pl-11 text-sm outline-none transition-colors focus:ring-2 focus:ring-emerald-500/40 ${
                    error
                      ? "border-rose-500"
                      : "border-border focus:border-emerald-500/50"
                  }`}
                />
                <Rocket className="absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              </div>
              {scanning ? (
                <button
                  onClick={onReset}
                  className="inline-flex items-center justify-center gap-2 rounded-xl bg-muted px-5 py-3 text-sm font-medium text-foreground transition-colors hover:bg-accent"
                >
                  <X className="h-4 w-4" strokeWidth={1.5} />
                  Stop
                </button>
              ) : (
                <button
                  onClick={handleSubmit}
                  className="inline-flex items-center justify-center gap-2 rounded-xl bg-emerald-500 px-6 py-3 text-sm font-semibold text-emerald-950 transition-all hover:bg-emerald-400 active:scale-[0.98]"
                >
                  Run audit
                  <ArrowRight className="h-4 w-4" strokeWidth={1.5} />
                </button>
              )}
            </div>
            {error && (
              <p className="mt-1.5 text-xs text-rose-400">{error}</p>
            )}
          </div>

          <div>
            <p className="mb-2 text-xs font-medium uppercase tracking-wide text-muted-foreground">
              Scan engines
            </p>
            <div className="flex flex-wrap gap-2">
              {OPTION_CONFIG.map((opt) => (
                <button
                  key={opt.key}
                  onClick={() => onToggleOption(opt.key)}
                  disabled={scanning}
                  title={opt.detail}
                  className={`inline-flex items-center gap-1.5 rounded-lg border px-3 py-1.5 text-xs font-medium transition-colors ${
                    options[opt.key]
                      ? "border-emerald-500/40 bg-emerald-500/10 text-emerald-400"
                      : "border-border bg-background text-muted-foreground hover:border-emerald-500/30"
                  }`}
                >
                  {options[opt.key] && (
                    <CheckCircle2 className="h-3.5 w-3.5" strokeWidth={1.5} />
                  )}
                  {opt.label}
                </button>
              ))}
            </div>
          </div>

          <div>
            <p className="mb-2 text-xs font-medium uppercase tracking-wide text-muted-foreground">
              Quick presets
            </p>
            <div className="flex flex-wrap gap-2">
              {PRESET_TARGETS.map((t) => (
                <button
                  key={t.url}
                  onClick={() => {
                    setUrl(t.url);
                    setError("");
                  }}
                  disabled={scanning}
                  className="rounded-lg border border-border bg-background px-3 py-1.5 text-xs text-muted-foreground transition-colors hover:border-emerald-500/30 hover:text-foreground"
                >
                  {t.label}
                </button>
              ))}
            </div>
          </div>

          {scanning && (
            <div className="mt-2 space-y-2">
              {steps.map((s, i) => (
                <div
                  key={s.label}
                  className={`flex items-start gap-3 rounded-xl border p-3 transition-all duration-300 ${
                    s.active
                      ? "border-emerald-500/40 bg-emerald-500/5"
                      : s.done
                        ? "border-border bg-muted/40"
                        : "border-border opacity-50"
                  }`}
                >
                  <div className="mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center">
                    {s.done ? (
                      <CheckCircle2
                        className="h-5 w-5 text-emerald-400"
                        strokeWidth={1.5}
                      />
                    ) : s.active ? (
                      <Loader2 className="h-5 w-5 animate-spin text-emerald-400" />
                    ) : (
                      <span className="h-2 w-2 rounded-full bg-muted-foreground/50" />
                    )}
                  </div>
                  <div>
                    <p className="text-sm font-medium">{s.label}</p>
                    {s.active && (
                      <p className="mt-0.5 text-xs text-muted-foreground">
                        {s.detail}
                      </p>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </motion.div>
    </section>
  );
}
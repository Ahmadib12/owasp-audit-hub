import type { FindingTmpl } from "./vulnerabilityPool";

const REF = (label: string, url: string): [string, string] => [label, url];
const OWASP = "https://owasp.org/";

export const POOL_A: FindingTmpl[] = [
  {
    id: "cwe-089-sqli",
    title: "SQL injection in product query",
    severity: "critical",
    category: "injection",
    cweId: "CWE-89",
    cweName: "Improper Neutralization of Special Elements used in SQL",
    file: "src/routes/products.ts",
    line: 42,
    detectedBy: "semgrep",
    description:
      "User-controlled input is concatenated directly into a SQL query, letting an attacker reshape the statement and dump, alter or delete rows.",
    impact:
      "Database read and write access, data exfiltration, and in worst cases remote code execution on the database server.",
    remediationSteps: [
      "Switch to parameterized queries or a prepared-statement ORM.",
      "Apply least-privilege roles to the application DB user.",
      "Add an allow-list validation layer for expected input shape.",
    ],
    vulnerable:
      "const rows = db.query('SELECT * FROM products WHERE id = ' + req.params.id);",
    secure:
      "const rows = await db.query('SELECT * FROM products WHERE id = $1', [req.params.id]);",
    explanation:
      "The secure version binds the id as a typed parameter rather than string interpolation, so it can never alter the query structure.",
    refs: [
      REF("OWASP SQL Injection", OWASP + "www-community/attacks/SQL_Injection"),
      REF("MITRE CWE-89", "https://cwe.mitre.org/data/definitions/89.html"),
    ],
  },
  {
    id: "cwe-079-xss",
    title: "Reflected XSS in search endpoint",
    severity: "high",
    category: "xss",
    cweId: "CWE-79",
    cweName: "Improper Neutralization of Input During Web Page Generation",
    file: "src/views/search.tsx",
    line: 18,
    detectedBy: "semgrep",
    description:
      "The search term is rendered into the DOM unescaped, allowing injected script payloads to execute in the viewer's browser.",
    impact:
      "Session hijacking, credential theft, and defacement of the application for every visitor of the malicious URL.",
    remediationSteps: [
      "HTML-encode all user-controlled output before rendering.",
      "Use a framework default that escapes by default.",
      "Apply a strict Content-Security-Policy to block inline scripts.",
    ],
    vulnerable: "return <div dangerouslySetInnerHTML={{ __html: query }} />",
    secure: "return <div>{query}</div>; // React auto-escapes",
    explanation:
      "Casting the term as a React child encodes it automatically, neutralizing any script that arrives in the query string.",
    refs: [
      REF("OWASP XSS", OWASP + "www-community/attacks/xss/"),
      REF("MITRE CWE-79", "https://cwe.mitre.org/data/definitions/79.html"),
    ],
  },
  {
    id: "cwe-319-cleartext",
    title: "Cleartext transmission of session tokens",
    severity: "critical",
    category: "cryptography",
    cweId: "CWE-319",
    cweName: "Cleartext Transmission of Sensitive Information",
    file: "src/index.ts",
    line: 9,
    detectedBy: "bandit",
    description:
      "The application binds to HTTP port 8080 and issues auth cookies without the Secure flag, sending tokens in the clear.",
    impact:
      "Session theft over network sniffing on Wi-Fi and shared networks, leading to complete account takeover.",
    remediationSteps: [
      "Force HTTPS and set HSTS on the app.",
      "Mark the session cookie Secure and SameSite=Strict.",
      "Redirect any HTTP request to its HTTPS equivalent.",
    ],
    vulnerable: 'app.listen(8080); res.cookie("session", token);',
    secure:
      'app.listen(443, { tls: tlsOpts }); res.cookie("session", token, { secure: true, httpOnly: true });',
    explanation:
      "Serving over TLS and flagging the cookie Secure guarantees the token is never transmitted in cleartext.",
    refs: [
      REF("OWASP TLS Cheat Sheet", "https://cheatsheetseries.owasp.org/cheatsheets/Transport_Layer_Protection_Cheat_Sheet.html"),
      REF("MITRE CWE-319", "https://cwe.mitre.org/data/definitions/319.html"),
    ],
  },
  {
    id: "cwe-918-ssrf",
    title: "SSRF via image proxy",
    severity: "high",
    category: "ssrf",
    cweId: "CWE-918",
    cweName: "Server-Side Request Forgery",
    file: "src/services/imageProxy.ts",
    line: 27,
    detectedBy: "semgrep",
    description:
      "The proxy fetches an arbitrary user-supplied URL and returns the response, giving attackers a bridge to the internal network.",
    impact:
      "Access to cloud metadata endpoints and internal services, enabling credential exfiltration and lateral movement.",
    remediationSteps: [
      "Maintain an allow-list of permitted remote hosts.",
      "Block loopback, link-local and cloud metadata address ranges.",
      "Disable automatic redirect following in the HTTP client.",
    ],
    vulnerable: "const buf = await fetch(userUrl).then((r) => r.arrayBuffer());",
    secure:
      "assertAllowedHost(new URL(userUrl)); const buf = await fetch(userUrl, { redirect: 'manual' }).then((r) => r.arrayBuffer());",
    explanation:
      "Validating the host before fetch and disabling redirects prevents SSRF to internal infrastructure.",
    refs: [
      REF("OWASP SSRF", OWASP + "www-community/attacks/Server_Side_Request_Forgery"),
      REF("MITRE CWE-918", "https://cwe.mitre.org/data/definitions/918.html"),
    ],
  },
  {
    id: "cwe-200-stacktrace",
    title: "Verbose stack trace disclosure",
    severity: "medium",
    category: "misconfig",
    cweId: "CWE-200",
    cweName: "Exposure of Sensitive Information to an Unauthorized Actor",
    file: "src/middleware/error.ts",
    line: 6,
    detectedBy: "bandit",
    description:
      "The error handler returns the raw exception message and stack trace to the client, leaking internal paths and library versions.",
    impact:
      "Information disclosure useful for precise exploit engineering against the host.",
    remediationSteps: [
      "Return a generic message to clients in production.",
      "Log the full stack server-side only.",
      "Disable debug and developer mode in production builds.",
    ],
    vulnerable: "res.status(500).json({ error: err.stack })",
    secure: "logError(err); res.status(500).json({ error: 'Internal Server Error', requestId })",
    explanation:
      "errorHandler logs the full stack server-side and returns only a generic message plus a correlation requestId, so no stack trace or internal path reaches the client.",
    refs: [
      REF("OWASP Logging Cheat Sheet", "https://cheatsheetseries.owasp.org/cheatsheets/Logging_Cheat_Sheet.html"),
      REF("MITRE CWE-200", "https://cwe.mitre.org/data/definitions/200.html"),
    ],
  },
  {
    id: "cwe-307-ratelimit",
    title: "Weak authentication rate limiting",
    severity: "medium",
    category: "auth",
    cweId: "CWE-307",
    cweName: "Improper Restriction of Excessive Authentication Attempts",
    file: "src/routes/auth.ts",
    line: 33,
    detectedBy: "manual",
    description:
      "The login endpoint has no throttling, allowing unlimited username and password brute-force attempts.",
    impact:
      "Credential stuffing and brute-force attacks lead to unauthorized account access.",
    remediationSteps: [
      "Apply per-IP and per-account rate limiting.",
      "Introduce progressive lockout and CAPTCHA after failures.",
      "Log and alert on repeated authentication failures.",
    ],
    vulnerable: 'router.post("/login", (req, res) => { validate(req.body); });',
    secure:
      'router.post("/login", rateLimit({ max: 5 }), (req, res) => { validate(req.body); });',
    explanation:
      "Wrapping the handler with a rate limiter caps attempts and slows brute-force campaigns.",
    refs: [
      REF("OWASP Authentication Cheat Sheet", "https://cheatsheetseries.owasp.org/cheatsheets/Authentication_Cheat_Sheet.html"),
      REF("MITRE CWE-307", "https://cwe.mitre.org/data/definitions/307.html"),
    ],
  },
  {
    id: "cwe-352-csrf",
    title: "Missing CSRF token on state-changing forms",
    severity: "high",
    category: "misconfig",
    cweId: "CWE-352",
    cweName: "Cross-Site Request Forgery",
    file: "src/routes/checkout.ts",
    line: 21,
    detectedBy: "semgrep",
    description:
      "Mutating endpoints accept cross-origin requests without synchronizer tokens, so a malicious page can drive authenticated actions.",
    impact:
      "Forced payments, account changes, and privilege escalation performed in the victim's session.",
    remediationSteps: [
      "Issue per-session CSRF tokens on every state-changing form.",
      "Validate the Origin and Referer headers server-side.",
      "Set SameSite=Strict on authentication cookies.",
    ],
    vulnerable:
      "app.post('/order', auth, async (req, res) => { await createOrder(req.body); });",
    secure:
      "app.post('/order', csrf({ cookie: true }), auth, handler); // signed session token",
    explanation:
      "Token verification proves the request originated from the trusted session page instead of a third-party origin.",
    refs: [
      REF("OWASP CSRF Prevention", "https://cheatsheetseries.owasp.org/cheatsheets/Cross-Site_Request_Forgery_Prevention_Cheat_Sheet.html"),
      REF("MITRE CWE-352", "https://cwe.mitre.org/data/definitions/352.html"),
    ],
  },
  {
    id: "cwe-287-authbypass",
    title: "Authorization bypass on admin routes",
    severity: "critical",
    category: "auth",
    cweId: "CWE-287",
    cweName: "Improper Authentication",
    file: "src/routes/admin.ts",
    line: 12,
    detectedBy: "semgrep",
    description:
      "Admin endpoints rely on client-supplied role claims instead of server-side session checks, so a forged header grants elevated access.",
    impact:
      "Full administrative takeover: user impersonation, data export, and configuration tampering.",
    remediationSteps: [
      "Add requireAuth to /admin/* to reject unauthenticated calls (401).",
      "Chain requireRole('admin') so the role is read from the verified session (403 on mismatch).",
      "Rotate leaked access tokens and audit privileged access.",
    ],
    vulnerable:
      "const role = req.headers['x-role'] ?? 'user'; if (role !== 'admin') return 403;",
    secure:
      "router.use('/admin', requireAuth, requireRole('admin')); // roles from the verified session",
    explanation:
      "requireAuth rejects unauthenticated calls with 401 and requireRole('admin') reads the role from the verified session (never a header), returning 403 when it does not match.",
    refs: [
      REF("OWASP Broken Access Control", OWASP + "Top10/A01_2021-Broken_Access_Control/"),
      REF("MITRE CWE-287", "https://cwe.mitre.org/data/definitions/287.html"),
    ],
  },
  {
    id: "cwe-094-rce",
    title: "Remote code execution via eval on input",
    severity: "critical",
    category: "injection",
    cweId: "CWE-94",
    cweName: "Improper Control of Generation of Code",
    file: "src/jobs/calculator.ts",
    line: 58,
    detectedBy: "bandit",
    description:
      "Arbitrary user input is passed to eval(), turning a calculator feature into a remote shell on the host.",
    impact:
      "Full server compromise, lateral movement, and ransomware deployment.",
    remediationSteps: [
      "Replace eval with a safe expression parser or math library.",
      "Sandbox any code execution behind a restricted VM.",
      "Reject payloads containing parentheses and assignment operators.",
    ],
    vulnerable: "const result = eval(input.expression); // user input reaches eval",
    secure:
      "const result = math.evaluate(input.expression, { allowed: ['+', '-', '*', '/'] });",
    explanation:
      "A constrained math evaluator has no access to process, filesystem, or network primitives, so it cannot execute system commands.",
    refs: [
      REF("OWASP Command Injection", OWASP + "www-community/attacks/Command_Injection"),
      REF("MITRE CWE-94", "https://cwe.mitre.org/data/definitions/94.html"),
    ],
  },
  {
    id: "cwe-611-xxe",
    title: "XXE in document import parser",
    severity: "high",
    category: "injection",
    cweId: "CWE-611",
    cweName: "Improper Restriction of XML External Entity Reference",
    file: "src/imports/xmlParser.ts",
    line: 14,
    detectedBy: "semgrep",
    description:
      "The XML parser resolves external entities, letting a crafted document read local files or probe internal network hosts.",
    impact:
      "Local file disclosure, internal network scanning, and denial of service through entity expansion.",
    remediationSteps: [
      "Disable DTD processing and external entity resolution.",
      "Prefer JSON or a non-entity XML parser.",
      "Validate document size before parsing.",
    ],
    vulnerable: "const doc = new DOMParser().parseFromString(xml, 'application/xml');",
    secure:
      "const doc = parseXml(xml, { processEntities: false, resolveExternals: false });",
    explanation:
      "Disabling entity resolution removes both arbitrary file reads and the billion-laughs expansion vector.",
    refs: [
      REF("OWASP XXE Prevention", "https://cheatsheetseries.owasp.org/cheatsheets/XML_External_Entity_Prevention_Cheat_Sheet.html"),
      REF("MITRE CWE-611", "https://cwe.mitre.org/data/definitions/611.html"),
    ],
  },
  {
    id: "cwe-502-deser",
    title: "Unsafe deserialization of profile payloads",
    severity: "high",
    category: "misconfig",
    cweId: "CWE-502",
    cweName: "Deserialization of Untrusted Data",
    file: "src/session/serializer.ts",
    line: 31,
    detectedBy: "bandit",
    description:
      "Untrusted bytes are deserialized through a gadget-capable format, which can execute code embedded in the payload.",
    impact:
      "Remote code execution, denial of service, and authentication bypass during session restore.",
    remediationSteps: [
      "Deserialize only allow-listed data classes.",
      "Sign and verify serialized payloads with a MAC.",
      "Prefer safe formats like JSON with strict schemas.",
    ],
    vulnerable: "const profile = pickle.loads(rawProfile); // attacker-controlled bytes",
    secure:
      "const profile = JSON.parse(verifyMac(rawProfile, SECRET)); // safe format + MAC",
    explanation:
      "Verifying a MAC before parsing guarantees the bytes were produced by the server, and JSON has no gadget chain.",
    refs: [
      REF("OWASP Deserialization Cheat Sheet", "https://cheatsheetseries.owasp.org/cheatsheets/Deserialization_Cheat_Sheet.html"),
      REF("MITRE CWE-502", "https://cwe.mitre.org/data/definitions/502.html"),
    ],
  },
  {
    id: "cwe-1336-tpl",
    title: "Server-side template injection in export blocks",
    severity: "critical",
    category: "injection",
    cweId: "CWE-1336",
    cweName: "Improper Neutralization of Special Elements Used in a Template Engine",
    file: "src/reports/render.ts",
    line: 66,
    detectedBy: "semgrep",
    description:
      "User-chosen report fields are interpolated into a template without escaping, allowing template syntax to execute engine functions.",
    impact:
      "Remote code execution and access to server environment secrets through template expressions.",
    remediationSteps: [
      "Pass report data as context objects, never as template text.",
      "Sandbox the template engine and disable dangerous functions.",
      "Escape and validate every interpolated field.",
    ],
    vulnerable: "const html = templateEngine.render(`<h1>${req.body.title}</h1>`, ctx);",
    secure:
      "const html = templateEngine.render('header', { title: esc(req.body.title) }, ctx);",
    explanation:
      "Rendering a named template with an escaped context value removes the ability to inject engine directives.",
    refs: [
      REF("OWASP SSTI", OWASP + "www-community/attacks/Server_Side_Template_Injection"),
      REF("MITRE CWE-1336", "https://cwe.mitre.org/data/definitions/1336.html"),
    ],
  },
  {
    id: "cwe-942-cors",
    title: "Permissive CORS allows credential theft",
    severity: "medium",
    category: "misconfig",
    cweId: "CWE-942",
    cweName: "Permissive Cross-domain Policy with Untrusted Domains",
    file: "src/middleware/cors.ts",
    line: 8,
    detectedBy: "manual",
    description:
      "The API echoes any Origin and enables credentials, so any malicious site can issue authenticated cross-origin requests.",
    impact:
      "Data theft from the victim's authenticated session and silent CSRF-style state changes.",
    remediationSteps: [
      "Whitelist exact trusted origins and never echo arbitrary Origin.",
      "Keep Access-Control-Allow-Credentials off for wildcard origins.",
      "Prefer SameSite cookies and token-based auth for APIs.",
    ],
    vulnerable: "app.use(cors({ origin: (o, cb) => cb(null, o), credentials: true }));",
    secure:
      "app.use(cors({ origin: ['https://app.example.com'], credentials: true }));",
    explanation:
      "A fixed allow-list removes the attacker's ability to obtain an authorized CORS response from their own origin.",
    refs: [
      REF("OWASP CORS", OWASP + "www-community/attacks/CORS_OriginHeaderScrutiny"),
      REF("MITRE CWE-942", "https://cwe.mitre.org/data/definitions/942.html"),
    ],
  },
];
import type { FindingTmpl } from "./vulnerabilityPool";

const REF = (label: string, url: string): [string, string] => [label, url];
const OWASP = "https://owasp.org/";

export const POOL_B: FindingTmpl[] = [
  {
    id: "cwe-1021-clickjack",
    title: "Clickjacking via missing frame protection",
    severity: "low",
    category: "misconfig",
    cweId: "CWE-1021",
    cweName: "Improper Restriction of Rendered UI Layers or Frames",
    file: "src/middleware/security.ts",
    line: 5,
    detectedBy: "manual",
    description:
      "No frame-ancestors CSP directive or X-Frame-Options header is set, so the page can be embedded in a rogue iframe.",
    impact:
      "Users are tricked into performing privileged actions inside invisible frames layered over attacker UI.",
    remediationSteps: [
      "Send X-Frame-Options: DENY or SAMEORIGIN.",
      "Add frame-ancestors 'none' to the CSP header.",
      "Audit embeds for partner integrations.",
    ],
    vulnerable: "// no frame protection header configured",
    secure: "res.setHeader('X-Frame-Options', 'DENY');",
    explanation:
      "Blocking frame embedding eliminates the overlay canvas an attacker needs for clickjacking.",
    refs: [
      REF("OWASP Clickjacking", OWASP + "cheatsheetseries.owasp.org/cheatsheets/Clickjacking_Defense_Cheat_Sheet.html"),
      REF("MITRE CWE-1021", "https://cwe.mitre.org/data/definitions/1021.html"),
    ],
  },
  {
    id: "cwe-295-invalidcert",
    title: "Invalid TLS certificate chain accepted",
    severity: "high",
    category: "cryptography",
    cweId: "CWE-295",
    cweName: "Improper Certificate Validation",
    file: "src/clients/apiClient.ts",
    line: 22,
    detectedBy: "bandit",
    description:
      "The HTTP client disables certificate verification, accepting self-signed or spoofed certificates without warning.",
    impact:
      "Man-in-the-middle interception of all API traffic and credential material.",
    remediationSteps: [
      "Keep rejectUnauthorized true by default; never disable TLS verification in production.",
      "Pin the expected certificate or public key.",
      "Use a private CA bundle for internal services.",
    ],
    vulnerable: "const client = new https.Agent({ rejectUnauthorized: false });",
    secure:
      "const rejectUnauthorized = !(ALLOW_INSECURE_TLS === 'true' && NODE_ENV !== 'production'); // default true",
    explanation:
      "apiClient defaults rejectUnauthorized to true and only relaxes it when ALLOW_INSECURE_TLS is set outside production, logging a warning whenever insecure mode is active.",
    refs: [
      REF("OWASP TLS Cheat Sheet", "https://cheatsheetseries.owasp.org/cheatsheets/Transport_Layer_Protection_Cheat_Sheet.html"),
      REF("MITRE CWE-295", "https://cwe.mitre.org/data/definitions/295.html"),
    ],
  },
  {
    id: "cwe-400-regexdos",
    title: "ReDoS: exponential regex on email input",
    severity: "medium",
    category: "misconfig",
    cweId: "CWE-400",
    cweName: "Uncontrolled Resource Consumption",
    file: "src/validators/email.ts",
    line: 3,
    detectedBy: "manual",
    description:
      "A nested quantifier regex runs in exponential time on long crafted strings, stalling the request thread.",
    impact:
      "Single requests can exhaust CPU, degrading or denying service for all users.",
    remediationSteps: [
      "Replace the regex with a linear-time validator or atomic groups.",
      "Cap input length before validation.",
      "Run validation outside the request hot path.",
    ],
    vulnerable: "const RE = /^([a-z0-9]+([._-][a-z0-9]+)*)+@[a-z0-9.-]+$/i;",
    secure: "const RE = /^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,}$/i; // linear",
    explanation:
      "Avoiding nested quantifiers over the same token class bounds the backtracking cost to linear time.",
    refs: [
      REF("OWASP ReDoS", OWASP + "www-community/attacks/Regular_expression_Denial_of_Service_-_ReDoS"),
      REF("MITRE CWE-400", "https://cwe.mitre.org/data/definitions/400.html"),
    ],
  },
  {
    id: "cwe-522-weakhash",
    title: "Passwords stored with unsalted MD5",
    severity: "high",
    category: "cryptography",
    cweId: "CWE-522",
    cweName: "Insufficiently Protected Credentials",
    file: "src/models/user.ts",
    line: 47,
    detectedBy: "bandit",
    description:
      "New account passwords are hashed with MD5 and no salt, making credentials trivially crackable on modern hardware.",
    impact:
      "Credential disclosure, account takeover, and cross-service compromise via password reuse.",
    remediationSteps: [
      "Hash with Argon2id or bcrypt (cost 12+).",
      "Rotate existing hashes on next login.",
      "Enforce a breach-checked password policy.",
    ],
    vulnerable: "const hash = crypto.createHash('md5').update(password).digest('hex');",
    secure: "const hash = await argon2.hash(password, { type: argon2.argon2id });",
    explanation:
      "Argon2id applies memory-hard key derivation with per-password salts, making brute force orders of magnitude slower.",
    refs: [
      REF("OWASP Password Storage", OWASP + "cheatsheetseries.owasp.org/cheatsheets/Password_Storage_Cheat_Sheet.html"),
      REF("MITRE CWE-522", "https://cwe.mitre.org/data/definitions/522.html"),
    ],
  },
  {
    id: "cwe-639-idor",
    title: "IDOR: object IDs exposed in URLs",
    severity: "high",
    category: "auth",
    cweId: "CWE-639",
    cweName: "Authorization Bypass Through User-Controlled Key",
    file: "src/routes/invoices.ts",
    line: 38,
    detectedBy: "semgrep",
    description:
      "Invoice records are fetched by a sequential id from the URL without verifying the requester owns the record.",
    impact:
      "Any authenticated user can read or mutate another customer's financial records.",
    remediationSteps: [
      "Resolve ownership server-side before returning records.",
      "Use unpredictable GUIDs instead of sequential ids.",
      "Audit logs for repeated cross-user access attempts.",
    ],
    vulnerable: "const invoice = await db.byId(req.params.id); // no ownership check",
    secure: "const invoice = await db.byIdForUser(req.params.id, req.session.user.id);",
    explanation:
      "Scoping the query to the session user proves ownership in the database layer itself.",
    refs: [
      REF("OWASP Broken Access Control", OWASP + "Top10/A01_2021-Broken_Access_Control/"),
      REF("MITRE CWE-639", "https://cwe.mitre.org/data/definitions/639.html"),
    ],
  },
  {
    id: "cwe-798-hardcoded",
    title: "Hardcoded API secret in source",
    severity: "critical",
    category: "cryptography",
    cweId: "CWE-798",
    cweName: "Use of Hard-coded Credentials",
    file: "src/config/prod.ts",
    line: 5,
    detectedBy: "bandit",
    description:
      "A live payment gateway secret is committed to the repository, visible to every developer and CI log.",
    impact:
      "Fraudulent charges, refund abuse, and full compromise of the payment integration.",
    remediationSteps: [
      "Rotate the exposed secret immediately.",
      "Move secrets to a managed vault with scoped access.",
      "Scan CI for secret patterns and block future commits.",
    ],
    vulnerable: "export const STRIPE_KEY = 'sk_live_4eC39HqLyjWDarjtT1zdp7dc';",
    secure: "export const STRIPE_KEY = process.env.STRIPE_KEY!; // vault-managed",
    explanation:
      "Reading from the environment at deploy time keeps the secret out of the source tree and CI history.",
    refs: [
      REF("OWASP Secrets Management", OWASP + "cheatsheetseries.owasp.org/cheatsheets/Secrets_Management_Cheat_Sheet.html"),
      REF("MITRE CWE-798", "https://cwe.mitre.org/data/definitions/798.html"),
    ],
  },
  {
    id: "cwe-770-unbounded",
    title: "Unbounded upload size leads to DoS",
    severity: "medium",
    category: "misconfig",
    cweId: "CWE-770",
    cweName: "Allocation of Resources Without Limits or Throttling",
    file: "src/middleware/upload.ts",
    line: 17,
    detectedBy: "manual",
    description:
      "The multipart upload handler imposes no size or count limit, allowing disk and memory exhaustion.",
    impact:
      "Storage capacity is drained and the instance can be crashed with a few large requests.",
    remediationSteps: [
      "Enforce file size and concurrency limits middleware-side.",
      "Stream to object storage instead of buffering in memory.",
      "Rate-limit uploads per user and IP.",
    ],
    vulnerable: "app.use(upload.single('file')); // no limits",
    secure:
      "app.use(upload.single('file', { limits: { fileSize: 10 * 1024 * 1024 } }));",
    explanation:
      "A hard size cap stops oversized payloads before they consume significant memory or disk.",
    refs: [
      REF("OWASP DoS", OWASP + "www-community/attacks/Denial_of_Service"),
      REF("MITRE CWE-770", "https://cwe.mitre.org/data/definitions/770.html"),
    ],
  },
  {
    id: "cwe-601-openredirect",
    title: "Open redirect in auth callback",
    severity: "low",
    category: "auth",
    cweId: "CWE-601",
    cweName: "URL Redirection to Untrusted Site",
    file: "src/routes/oauth.ts",
    line: 29,
    detectedBy: "semgrep",
    description:
      "The post-login redirect target is taken from the query string without an allow-list, sending users to attacker sites.",
    impact:
      "Phishing and credential theft when victims land on lookalike domains after sign-in.",
    remediationSteps: [
      "Whitelist redirect targets against configured domains.",
      "Ignore or sign the redirect parameter.",
      "Show a confirmation page for unknown targets.",
    ],
    vulnerable: "res.redirect(302, req.query.redirect ?? '/dashboard');",
    secure:
      "const target = ALLOWED_REDIRECTS[req.query.redirect] ?? '/dashboard'; res.redirect(302, target);",
    explanation:
      "Mapping the value through an allow-list turns an untrusted parameter into a controlled lookup key.",
    refs: [
      REF("OWASP Open Redirect", OWASP + "cheatsheetseries.owasp.org/cheatsheets/Unvalidated_Redirects_and_Forwards_Cheat_Sheet.html"),
      REF("MITRE CWE-601", "https://cwe.mitre.org/data/definitions/601.html"),
    ],
  },
  {
    id: "cwe-209-headerleak",
    title: "Sensitive data in debug response headers",
    severity: "low",
    category: "misconfig",
    cweId: "CWE-209",
    cweName: "Generation of Error Message Containing Sensitive Information",
    file: "src/middleware/error.ts",
    line: 41,
    detectedBy: "manual",
    description:
      "Custom response headers expose internal hostname, framework version, and build SHA to every caller.",
    impact:
      "Reconnaissance value for fingerprinting and targeting known CVEs of the exposed versions.",
    remediationSteps: [
      "Strip X-Debug, X-Stack, X-Error and X-Debug-Host outside development.",
      "Randomize or remove build metadata from public responses.",
      "Verify headers in pre-deploy integration tests.",
    ],
    vulnerable: "res.setHeader('X-Debug-Host', os.hostname()); res.setHeader('Server', 'Express/4.18');",
    secure: "if (NODE_ENV !== 'development') for (const h of ['X-Debug', 'X-Stack', 'X-Error', 'X-Debug-Host']) res.removeHeader(h);",
    explanation:
      "errorHandler strips X-Debug, X-Stack, X-Error and X-Debug-Host in every non-development environment, so debug metadata never ships to production callers.",
    refs: [
      REF("OWASP Error Handling", OWASP + "cheatsheetseries.owasp.org/cheatsheets/Error_Handling_Cheat_Sheet.html"),
      REF("MITRE CWE-209", "https://cwe.mitre.org/data/definitions/209.html"),
    ],
  },
  {
    id: "cwe-20-multipart",
    title: "Unvalidated multipart parameter pollution",
    severity: "medium",
    category: "injection",
    cweId: "CWE-20",
    cweName: "Improper Input Validation",
    file: "src/routes/api.ts",
    line: 54,
    detectedBy: "semgrep",
    description:
      "API handlers trust duplicated and mixed-case parameters from the query string, letting checks be bypassed with polluted values.",
    impact:
      "Validation bypass leading to injection, price tampering, and mass-assignment attacks.",
    remediationSteps: [
      "Parse parameters once from a single canonical source.",
      "Reject duplicate keys with 400 responses.",
      "Validate shapes with schema-first tooling.",
    ],
    vulnerable: "const qty = req.query.qty ?? req.body.qty; // dual source",
    secure: "const { qty } = validateSchema(req.parsedParams, schema);",
    explanation:
      "Reading from one validated source removes ambiguity attackers exploit between duplicate keys.",
    refs: [
      REF("OWASP Input Validation", OWASP + "cheatsheetseries.owasp.org/cheatsheets/Input_Validation_Cheat_Sheet.html"),
      REF("MITRE CWE-20", "https://cwe.mitre.org/data/definitions/20.html"),
    ],
  },
  {
    id: "cwe-311-missingtls",
    title: "Missing HSTS on production host",
    severity: "medium",
    category: "cryptography",
    cweId: "CWE-311",
    cweName: "Missing Encryption of Sensitive Data",
    file: "src/index.ts",
    line: 12,
    detectedBy: "manual",
    description:
      "TLS is active but strict-transport-security is absent, so a first visit can be downgraded to HTTP by a mid-network attacker.",
    impact:
      "Session tokens and form data can be intercepted during the initial insecure request.",
    remediationSteps: [
      "Add Strict-Transport-Security with max-age >= 31536000.",
      "Submit the domain to the HSTS preload list.",
      "Serve all subdomains over HTTPS exclusively.",
    ],
    vulnerable: "// no strict-transport-security header",
    secure: "res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');",
    explanation:
      "HSTS tells browsers to refuse plaintext connections to the domain from the very first visit onward.",
    refs: [
      REF("OWASP HSTS Cheat Sheet", OWASP + "cheatsheetseries.owasp.org/cheatsheets/HTTP_Strict_Transport_Security_Cheat_Sheet.html"),
      REF("MITRE CWE-311", "https://cwe.mitre.org/data/definitions/311.html"),
    ],
  },
  {
    id: "cwe-779-swagger",
    title: "Exposed Swagger/OpenAPI documentation",
    severity: "medium",
    category: "misconfig",
    cweId: "CWE-200",
    cweName: "Exposure of Sensitive Information to an Unauthorized Actor",
    file: "docs/openapi.yaml",
    line: 1,
    detectedBy: "manual",
    description:
      "Interactive API documentation is published to the internet, listing every endpoint, schema, and internal path.",
    impact:
      "Accelerates targeted exploitation by revealing undocumented debug routes and data models.",
    remediationSteps: [
      "Protect /docs, /openapi and /swagger with requireAuth or disable them in production.",
      "Strip internal endpoints from public specs.",
      "Monitor access logs for spec file hits.",
    ],
    vulnerable: "app.use('/docs', swaggerUi.serve, swaggerUi.setup(spec));",
    secure: "if (NODE_ENV !== 'production') app.use('/docs', requireAuth, swaggerUi.serve, swaggerUi.setup(spec));",
    explanation:
      "Docs routes are gated behind requireAuth and disabled entirely when NODE_ENV is production, so the OpenAPI surface is never exposed to anonymous callers.",
    refs: [
      REF("OWASP API Security", OWASP + "API-Security/editions/2023/en/0x11-t10/"),
      REF("MITRE CWE-200", "https://cwe.mitre.org/data/definitions/200.html"),
    ],
  },
  {
    id: "cwe-330-weakrand",
    title: "Predictable random token generation",
    severity: "medium",
    category: "cryptography",
    cweId: "CWE-330",
    cweName: "Use of Insufficiently Random Values",
    file: "src/tokens/reset.ts",
    line: 8,
    detectedBy: "bandit",
    description:
      "Password-reset tokens are produced with Math.random, whose outputs are predictable enough to guess in bulk.",
    impact:
      "Account takeover by predicting reset tokens for targeted victims.",
    remediationSteps: [
      "Generate secrets with crypto.getRandomValues or a CSPRNG.",
      "Expire tokens in 10-15 minutes and single-use them.",
      "Rate-limit token validation attempts.",
    ],
    vulnerable: "const token = Math.random().toString(36).slice(2); // predictable",
    secure: "const token = crypto.randomBytes(32).toString('hex'); // CSPRNG",
    explanation:
      "A cryptographic generator produces 256 bits of unpredictable entropy, far beyond brute-force reach.",
    refs: [
      REF("OWASP Cryptographic Storage", OWASP + "cheatsheetseries.owasp.org/cheatsheets/Cryptographic_Storage_Cheat_Sheet.html"),
      REF("MITRE CWE-330", "https://cwe.mitre.org/data/definitions/330.html"),
    ],
  },
];
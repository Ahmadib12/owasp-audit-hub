import type {
  AuditResult,
  Finding,
  FindingCategory,
  Severity,
} from "../types";
import { VULNERABILITY_POOL } from "./vulnerabilityPool";
import type { FindingTmpl } from "./vulnerabilityPool";

/* ------------------------------------------------------------------ */
/* Domain & URL heuristic profiler                                     */
/* ------------------------------------------------------------------ */

export type TargetArchetype = "fintech" | "ecommerce" | "legacy" | "generic";

interface ProfileRule {
  match: (host: string, path: string) => boolean;
  archetype: TargetArchetype;
}

const PROFILE_RULES: ProfileRule[] = [
  {
    match: (h) =>
      /(^|\.)(stripe|apple|github|google|microsoft|amazon|paypal|adyen|chase|visa|mastercard|bank|fintech)/i.test(h),
    archetype: "fintech",
  },
  {
    match: (h, p) =>
      /(^|\.)(shop|store|mall|checkout|cart|market|ebay|etsy|shopify|amazon)/i.test(h) ||
      /checkout|cart|store/i.test(p),
    archetype: "ecommerce",
  },
  {
    match: (h, p) =>
      /^(localhost|127\.0\.0\.1|dev\.|test\.|staging\.|admin\.|api\.|old\.|legacy\.|preprod)/i.test(h) ||
      /dev|test|admin|debug|staging|beta|internal/i.test(p),
    archetype: "legacy",
  },
  { match: () => true, archetype: "generic" },
];

/** Deterministic 32-bit FNV-1a hash so the same URL always yields the same profile. */
export function hashString(input: string): number {
  let h = 2166136261;
  for (let i = 0; i < input.length; i++) {
    h ^= input.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

const SEV_WEIGHT: Record<Severity, number> = {
  critical: 17,
  high: 9,
  medium: 5,
  low: 2,
  passed: 0,
};

const byId = (id: string): FindingTmpl => {
  const t = VULNERABILITY_POOL.find((x) => x.id === id);
  if (!t) throw new Error(`Unknown finding template ${id}`);
  return t;
};

function toFinding(t: FindingTmpl, host: string, rank: number): Finding {
  return {
    id: `${t.id}-${host}-${rank}`,
    title: t.title,
    severity: t.severity,
    category: t.category,
    cweId: t.cweId,
    cweName: t.cweName,
    file: t.file,
    line: t.line + rank,
    detectedBy: t.detectedBy,
    description: t.description,
    impact: t.impact,
    remediationSteps: t.remediationSteps,
    code: { vulnerable: t.vulnerable, secure: t.secure, explanation: t.explanation },
    references: t.refs.map(([label, url]) => ({ label, url })),
  };
}

/** Deterministic pick of distinct templates for the generic archetype. */
function pickForHash(host: string, count: number): FindingTmpl[] {
  const pool = [...VULNERABILITY_POOL];
  let seed = hashString(host);
  const picked: FindingTmpl[] = [];
  while (picked.length < count && pool.length > 0) {
    seed = Math.imul(seed ^ (seed >>> 15), 2246822519) >>> 0;
    const idx = seed % pool.length;
    const [t] = pool.splice(idx, 1);
    picked.push(t);
  }
  return picked;
}

const PROFILE_FINDINGS: Record<TargetArchetype, string[] | null> = {
  fintech: null, // dynamic: only low/medium items, few of them
  ecommerce: [
    "cwe-352-csrf",
    "cwe-079-xss",
    "cwe-942-cors",
    "cwe-639-idor",
    "cwe-311-missingtls",
    "cwe-601-openredirect",
    "cwe-209-headerleak",
    "cwe-522-weakhash",
  ],
  legacy: [
    "cwe-089-sqli",
    "cwe-918-ssrf",
    "cwe-094-rce",
    "cwe-798-hardcoded",
    "cwe-502-deser",
    "cwe-779-swagger",
    "cwe-295-invalidcert",
    "cwe-311-missingtls",
    "cwe-200-stacktrace",
  ],
  generic: null,
};

const HEADER_SETS: Record<TargetArchetype, { name: string; passed: boolean }[]> = {
  fintech: [
    { name: "Content-Security-Policy", passed: true },
    { name: "Strict-Transport-Security", passed: true },
    { name: "X-Content-Type-Options", passed: true },
    { name: "X-Frame-Options", passed: true },
    { name: "Referrer-Policy", passed: true },
    { name: "Permissions-Policy", passed: false },
  ],
  ecommerce: [
    { name: "Content-Security-Policy", passed: false },
    { name: "Strict-Transport-Security", passed: true },
    { name: "X-Content-Type-Options", passed: true },
    { name: "X-Frame-Options", passed: false },
    { name: "Referrer-Policy", passed: false },
    { name: "Permissions-Policy", passed: false },
  ],
  legacy: [
    { name: "Content-Security-Policy", passed: false },
    { name: "Strict-Transport-Security", passed: false },
    { name: "X-Content-Type-Options", passed: false },
    { name: "X-Frame-Options", passed: false },
    { name: "Referrer-Policy", passed: false },
    { name: "Permissions-Policy", passed: false },
  ],
  generic: [
    { name: "Content-Security-Policy", passed: false },
    { name: "Strict-Transport-Security", passed: false },
    { name: "X-Content-Type-Options", passed: true },
    { name: "X-Frame-Options", passed: false },
    { name: "Referrer-Policy", passed: true },
    { name: "Permissions-Policy", passed: false },
  ],
};

const TECH_STACKS: Record<TargetArchetype, string[][]> = {
  fintech: [
    ["React 18", "Node.js 20", "PostgreSQL 16", "AWS WAF", "Vault", "Stripe Connect"],
    ["Next.js 14", "TypeScript", "Aurora MySQL", "Cloudflare", "HashiCorp Vault"],
  ],
  ecommerce: [
    ["React 18", "Node.js 18", "MongoDB 7", "Redis", "Stripe", "Vercel"],
    ["Next.js 13", "Express 4", "PostgreSQL 15", "Shopify API", "CloudFront"],
  ],
  legacy: [
    ["Python 2.7", "Flask 1.0", "SQLite 3", "Apache 2.4", "No HSTS"],
    ["Java 8", "Tomcat 9", "MySQL 5.6", "Struts 2.3", "SOAP APIs"],
  ],
  generic: [
    ["React", "Node.js", "PostgreSQL"],
    ["Vue 3", "Express", "MySQL"],
    ["Angular 15", ".NET 8", "SQL Server"],
  ],
};

function certExpiryFor(archetype: TargetArchetype, h: number): string {
  const year =
    new Date().getFullYear() +
    (archetype === "fintech" || archetype === "generic" ? 1 : 0);
  const months = ["Jan", "Apr", "Jul", "Oct", "Dec"];
  return `${months[h % months.length]} ${year}`;
}

/* ------------------------------------------------------------------ */
/* Main entry: full deterministic audit                                */
/* ------------------------------------------------------------------ */

export function buildAudit(targetUrl: string): AuditResult {
  const url = new URL(targetUrl);
  const host = url.hostname;
  const path = url.pathname;
  const rule = PROFILE_RULES.find((r) => r.match(host, path)) ?? PROFILE_RULES[3];
  const archetype = rule.archetype;
  const h = hashString(host + path);

  // ---- findings ----
  let findings: Finding[] = [];
  if (profil(archetype) === "fintech") {
    const calm = VULNERABILITY_POOL.filter((t) => t.severity === "low" || t.severity === "medium");
    const start = h % calm.length;
    findings = [calm[start], calm[(start + 1) % calm.length]].map((t, i) =>
      toFinding(t, host, i),
    );
  } else {
    const ids = PROFILE_FINDINGS[archetype];
    if (ids) {
      const list = ids.map(byId);
      const seed = h % 2;
      const rotated = [...list.slice(seed), ...list.slice(0, seed)];
      findings = rotated.map((t, i) => toFinding(t, host, i));
    } else {
      findings = pickForHash(host, 4 + (h % 5)).map((t, i) => toFinding(t, host, i));
    }
  }
  // Ensure a passed-check-like low item for fintech realism every second scan
  if (findings.length < 2) {
    const low = VULNERABILITY_POOL.filter((t) => t.severity === "low");
    findings.push(toFinding(low[h % low.length], host, findings.length));
  }

  const critical = findings.filter((f) => f.severity === "critical").length;
  const high = findings.filter((f) => f.severity === "high").length;
  const medium = findings.filter((f) => f.severity === "medium").length;
  const low = findings.filter((f) => f.severity === "low").length;

  // ---- headers & tech stack ----
  const headerChecks = HEADER_SETS[archetype].map((c, i) =>
    archetype === "generic" && i === 1 ? { ...c, passed: h % 3 !== 0 } : c,
  );
  const passedHeaders = headerChecks.filter((c) => c.passed).length;
  const passed = 6 + passedHeaders; // 6 base optimistic checks + header passes
  const techStack = TECH_STACKS[archetype][h % TECH_STACKS[archetype].length];

  // ---- score ----
  const base =
    archetype === "fintech" ? 96 : archetype === "ecommerce" ? 66 : archetype === "legacy" ? 42 : 62;
  const penalty =
    critical * SEV_WEIGHT.critical + high * SEV_WEIGHT.high + medium * SEV_WEIGHT.medium + low * SEV_WEIGHT.low - passedHeaders * 3;
  let score = Math.round(base - penalty + (h % 5));
  score = Math.max(18, Math.min(98, score));
  if (archetype === "fintech") score = Math.max(90, score);
  if (archetype === "legacy") score = Math.min(54, score);
  if (archetype === "ecommerce") score = Math.min(72, Math.max(58, score));

  const tier: "A" | "C" | "F" =
    score >= 85 ? "A" : score >= 60 ? "C" : "F";

  const catMap = new Map<FindingCategory, number>();
  findings.forEach((f) => catMap.set(f.category, (catMap.get(f.category) ?? 0) + 1));

  const trendBase =
    archetype === "fintech" ? 88 : archetype === "ecommerce" ? 55 : archetype === "legacy" ? 32 : 50;

  return {
    id: `${Date.now()}-${h.toString(36)}`,
    targetUrl,
    scannedAt: new Date().toISOString(),
    score,
    passed,
    warnings: medium + low,
    critical,
    high,
    medium,
    low,
    avgRemediationDays: Math.max(2, Math.round((critical + high) * 1.4 + medium * 0.8)),
    scanOptions: ["semgrep", "bandit", "ssl", "headers"],
    findings,
    categoryCounts: Array.from(catMap.entries()).map(([category, count]) => ({ category, count })),
    trend: [
      { label: "W-4", score: Math.min(100, Math.max(0, trendBase + 9)) },
      { label: "W-3", score: Math.min(100, Math.max(0, trendBase + 6)) },
      { label: "W-2", score: Math.min(100, Math.max(0, trendBase + 3)) },
      { label: "W-1", score: Math.min(100, Math.max(0, trendBase + 1)) },
      { label: "Now", score },
    ],
    compliances: [
      { standard: "OWASP Top 10", status: tier === "A", note: tier === "A" ? "All clear" : `${critical + high} findings open` },
      { standard: "OWASP ASVS L1", status: critical === 0, note: critical === 0 ? "Level 1 verified" : "Level 1 gaps" },
      { standard: "ISO 27001", status: tier === "A", note: tier === "A" ? "Controls in place" : "Controls to enforce" },
      { standard: "PCI DSS 4.0", status: tier === "A", note: tier === "A" ? "Compliant" : "Requires hardening" },
    ],
    meta: {
      tier,
      archetype,
      techStack,
      headerChecks,
      scanMs: 2100 + (h % 2800),
      latencyMs: 80 + (h % 480),
      sslValidThrough: certExpiryFor(archetype, h),
    },
  };
}

function profil(x: TargetArchetype): TargetArchetype {
  return x;
}

/* ------------------------------------------------------------------ */
/* Score board + export artifacts                                      */
/* ------------------------------------------------------------------ */

export function createScoreBoard(targetUrl: string) {
  const audit = buildAudit(targetUrl);
  return {
    findings: audit.findings,
    critical: audit.critical,
    high: audit.high,
    medium: audit.medium,
    low: audit.low,
    passed: audit.passed,
  };
}

export function buildSemgrepJson(targetUrl: string, findings: Finding[]) {
  const host = new URL(targetUrl).hostname;
  return {
    schema: "https://json.schemastore.org/semgrep.json",
    version: "1.4.0",
    results: findings
      .filter((f) => f.detectedBy === "semgrep" || f.detectedBy === "manual")
      .map((f) => ({
        check_id: `rules.${f.cweId.toLowerCase().replace("-", "")}`,
        path: f.file,
        start: { line: f.line, col: 1 },
        end: { line: f.line + 3, col: 80 },
        extra: {
          message: `${f.cweId} - ${f.title}`,
          severity: f.severity.toUpperCase(),
          metadata: { cwe: [f.cweId], technology: ["react"], confidence: "HIGH" },
        },
      })),
    errors: [],
    target: host,
  };
}

export function buildBanditJson(targetUrl: string, findings: Finding[]) {
  const host = new URL(targetUrl).hostname;
  const sev = { CRITICAL: 0, HIGH: 0, MEDIUM: 0, LOW: 0 };
  const bandit = findings.filter((f) => f.detectedBy === "bandit");
  bandit.forEach((f) => {
    sev[f.severity.toUpperCase() as keyof typeof sev] += 1;
  });
  return {
    generated_at: new Date().toISOString(),
    metrics: { totals: { SEVERITY: sev } },
    results: bandit.map((f) => ({
      code: "BXXX",
      filename: f.file,
      issue_cwe: {
        id: Number(f.cweId.split("-")[1]),
        link: `https://cwe.mitre.org/data/definitions/${f.cweId.split("-")[1]}.html`,
      },
      issue_severity: f.severity.toUpperCase(),
      issue_text: f.title,
      line_number: f.line,
      test_id: f.cweId,
    })),
    errors: [],
    target: host,
  };
}

export function gradeForScore(score: number): "A" | "B" | "C" | "D" | "F" {
  if (score >= 90) return "A";
  if (score >= 80) return "B";
  if (score >= 65) return "C";
  if (score >= 50) return "D";
  return "F";
}
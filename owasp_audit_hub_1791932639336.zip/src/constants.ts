import type {
  FindingCategory,
  OwaspItem,
  ScanStep,
  Severity,
} from "./types";

export const BRAND_NAME = "CyberAudit Pro";

export const SEVERITY_META: Record<
  Severity,
  { label: string; color: string; bg: string; border: string }
> = {
  critical: {
    label: "Critical",
    color: "#f43f5e",
    bg: "bg-rose-500/10",
    border: "border-rose-500/40",
  },
  high: {
    label: "High",
    color: "#fb923c",
    bg: "bg-orange-500/10",
    border: "border-orange-500/40",
  },
  medium: {
    label: "Medium",
    color: "#f59e0b",
    bg: "bg-amber-500/10",
    border: "border-amber-500/40",
  },
  low: {
    label: "Low",
    color: "#38bdf8",
    bg: "bg-sky-500/10",
    border: "border-sky-500/40",
  },
  passed: {
    label: "Passed",
    color: "#10b981",
    bg: "bg-emerald-500/10",
    border: "border-emerald-500/40",
  },
};

export const CATEGORY_META: Record<FindingCategory, string> = {
  injection: "Injection",
  auth: "Authentication",
  cryptography: "Cryptography",
  misconfig: "Misconfiguration",
  ssrf: "SSRF",
  xss: "XSS",
};

export const SCAN_STEPS: ScanStep[] = [
  {
    label: "DNS Resolution",
    detail: "Resolving A/AAAA records and checking CDN header propagation.",
    done: false,
    active: false,
  },
  {
    label: "TLS / SSL Handshake",
    detail: "Verifying certificate chain, expiry and protocol versions.",
    done: false,
    active: false,
  },
  {
    label: "Header Inspection",
    detail: "Checking CSP, HSTS, X-Frame-Options and security headers.",
    done: false,
    active: false,
  },
  {
    label: "SAST + Semgrep Rules",
    detail: "Statically parsing code paths against OWASP rule packs.",
    done: false,
    active: false,
  },
  {
    label: "Bandit Python Heuristics",
    detail: "Running Python AST taint analysis for dangerous calls.",
    done: false,
    active: false,
  },
  {
    label: "OWASP Rule Evaluation",
    detail: "Mapping findings to the OWASP Top 10 taxonomy.",
    done: false,
    active: false,
  },
];

export const OWASP_ITEMS: OwaspItem[] = [
  {
    id: "a01",
    code: "A01",
    title: "Broken Access Control",
    summary:
      "Restrictions on authenticated users are not properly enforced, allowing privilege escalation or unauthorized access to other accounts.",
    attackScenario:
      "An attacker changes the id parameter in an API request (/profile/1002) to access another user's payment details without owning that record.",
    impact:
      "Account takeover, data breach of PII, and regulatory fines under GDPR or PCI DSS.",
    smeRisk:
      "An SME invoicing portal that exposes all customers in one table without row-level checks can leak financial records.",
    checklist: [
      "Enforce server-side authorization on every endpoint.",
      "Deny access to any resource by default.",
      "Hash and re-validate object IDs, never trust client input.",
    ],
    remediationTemplate:
      "app.get('/profile', auth, (req,res) => { const uid = req.session.user.id; const row = db.byId(req.query.id); if (row.owner !== uid) return res.status(403); })",
  },
  {
    id: "a02",
    code: "A02",
    title: "Cryptographic Failures",
    summary:
      "Sensitive data exposed due to weak or absent encryption in transit or at rest.",
    attackScenario:
      "Passwords are stored in plain text in the database, and the admin panel is reachable over HTTP on port 8080.",
    impact:
      "Credential theft, identity fraud, and complete compromise of stored customer data.",
    smeRisk:
      "A small e-commerce shop using insecure random password hashing and no TLS on the checkout flow.",
    checklist: [
      "Use Argon2id or bcrypt (cost >= 12) for password hashing.",
      "Redirect all HTTP traffic to HTTPS with HSTS.",
      "Encrypt data at rest with AES-256 and rotate keys.",
    ],
    remediationTemplate:
      "const hash = await argon2.hash(pw, { type: argon2.argon2id }); res.redirect(301, 'https://' + req.hostname + req.url);",
  },
  {
    id: "a03",
    code: "A03",
    title: "Injection",
    summary:
      "Untrusted input is concatenated into SQL, OS, or template queries.",
    attackScenario:
      "An attacker submits ' OR '1'='1 in the login field to bypass authentication and dump the users table.",
    impact:
      "Full database compromise, ransomware payload delivery, and mass data exfiltration.",
    smeRisk:
      "An SME inventory app building SQL strings with template literals becomes trivially exploitable via search boxes.",
    checklist: [
      "Use parameterized queries or an ORM at all times.",
      "Apply the principle of least privilege to DB users.",
      "Validate and sanitize all input with allow-lists.",
    ],
    remediationTemplate:
      "const rows = await db.query('SELECT * FROM products WHERE id = $1', [req.params.id]);",
  },
  {
    id: "a04",
    code: "A04",
    title: "Insecure Design",
    summary:
      "Architectural flaws and missing threat modeling that no amount of patching can fix.",
    attackScenario:
      "A rate-limit bypass in the password reset flow lets an attacker brute-force tokens because no throttling was designed in.",
    impact:
      "Systematic vulnerabilities that persist across releases and scale with users.",
    smeRisk:
      "An SME without a security review process ships a public admin endpoint with default credentials.",
    checklist: [
      "Threat-model every new feature during design.",
      "Enforce rate limiting and graduated lockouts.",
      "Test with security-focused user stories in CI.",
    ],
    remediationTemplate:
      "rateLimit({ windowMs: 15 * 60 * 1000, max: 5, keyGenerator: (req) => req.ip });",
  },
  {
    id: "a05",
    code: "A05",
    title: "Security Misconfiguration",
    summary:
      "Unsafe defaults, verbose error messages, and unhardened infrastructure.",
    attackScenario:
      "A debug console with default admin/admin credentials is left open on the staging server exposed to the internet.",
    impact:
      "System takeover and reconnaissance into internal services.",
    smeRisk:
      "An SME launching a PaaS box without disabling directory listing and default accounts.",
    checklist: [
      "Disable verbose stack traces and directory listing.",
      "Remove default and test accounts.",
      "Apply a hard baseline to servers and containers.",
    ],
    remediationTemplate:
      "app.disable('x-powered-by'); app.set('env', 'production'); server.listen(443);",
  },
  {
    id: "a06",
    code: "A06",
    title: "Vulnerable and Outdated Components",
    summary:
      "Using libraries and frameworks with known exploitable CVEs.",
    attackScenario:
      "An exploit known as CVE-2021-44228 (Log4Shell) is triggered via a crafted log message in a legacy Java service.",
    impact:
      "Remote code execution and supply-chain compromise.",
    smeRisk:
      "An SME fetching a payment library pinned two majors behind the current secure release.",
    checklist: [
      "Automatically scan the SBOM with tools like Trivy.",
      "Update dependencies on a cadence, not ad hoc.",
      "Monitor CVEs for the exact versions in use.",
    ],
    remediationTemplate:
      "docker scan --severity high app:latest; npm audit fix --force;",
  },
  {
    id: "a07",
    code: "A07",
    title: "Identification and Authentication Failures",
    summary:
      "Weak login mechanisms and session handling that allow credential theft.",
    attackScenario:
      "A session cookie is sent without the Secure and SameSite attributes, so it can be stolen over an XSS vector.",
    impact:
      "Account takeover, session hijacking, and fraud.",
    smeRisk:
      "An SME portal that never expires sessions and accepts list of the 1000 most common passwords.",
    checklist: [
      "Implement MFA for admin and privileged roles.",
      "Rotate session tokens on login and shorten lifetimes.",
      "Enforce a strong password policy and lockout.",
    ],
    remediationTemplate:
      "cookie: { httpOnly: true, secure: true, sameSite: 'strict', maxAge: 15 * 60 * 1000 }",
  },
  {
    id: "a08",
    code: "A08",
    title: "Software and Data Integrity Failures",
    summary:
      "Unverified update pipelines and CI/CD chains that can be injected with malicious code.",
    attackScenario:
      "A supply-chain agent publishes a poisoned npm package with a similar name that gets pulled in by a typo squatting dependency.",
    impact:
      "Dependency masquerading, backdoored artifacts, and ransomware.",
    smeRisk:
      "An SME auto-deploying on every push with unsigned artifacts.",
    checklist: [
      "Verify code signing and checksums on all artifacts.",
      "Pin dependency versions and use lockfiles.",
      "Require human approval for production promotion.",
    ],
    remediationTemplate:
      "npm ci --only=prod; sha256sum app.bin; cosign verify $IMAGE",
  },
  {
    id: "a09",
    code: "A09",
    title: "Security Logging and Monitoring Failures",
    summary:
      "No visibility into breaches because events are not logged or monitored.",
    attackScenario:
      "An attacker slowly exfiltrates records for months while failed logins and unusual API calls go completely unnoticed.",
    impact:
      "Extended dwell time and massive data loss under the radar.",
    smeRisk:
      "An SME relying on console logs that are never collected or alerted on.",
    checklist: [
      "Log authentication events, failures and access anomalies.",
      "Correlate logs with a SIEM or alert pipeline.",
      "Keep logs immutable and backed up off-box.",
    ],
    remediationTemplate:
      "logger.info({event:'login_failed', ip, count}, {alert: 'auth-anomaly'});",
  },
  {
    id: "a10",
    code: "A10",
    title: "Server-Side Request Forgery (SSRF)",
    summary:
      "An attacker tricks the server into fetching an internal resource by controlling the URL the server requests.",
    attackScenario:
      "An image-preview feature accepts a URL and the server fetches http://169.254.169.254/latest/meta-data to steal cloud credentials.",
    impact:
      "Internal network scanning, cloud credential theft, and lateral movement.",
    smeRisk:
      "An SME PDF renderer that fetches attacker-supplied URLs on the internal network.",
    checklist: [
      "Whitelist permitted hostnames and disable URL redirects.",
      "Block loopback and cloud metadata addresses.",
      "Route outbound fetches through an allowlisted proxy.",
    ],
    remediationTemplate:
      "const allowed = ['https://img.example.com']; if (!allowed.includes(host)) throw new Error('blocked');",
  },
];

export const SECURITY_HEADERS = [
  { name: "Content-Security-Policy", passed: true },
  { name: "Strict-Transport-Security", passed: true },
  { name: "X-Content-Type-Options", passed: true },
  { name: "X-Frame-Options", passed: false },
  { name: "Referrer-Policy", passed: true },
];

/** Re-export the new deterministic engine APIs so component imports keep working. */
export { buildSemgrepJson, buildBanditJson, createScoreBoard } from "./lib/scannerEngine";
export type { DemoPreset, TargetArchetype, GradeTier, HeaderCheck, AuditMeta } from "./types";
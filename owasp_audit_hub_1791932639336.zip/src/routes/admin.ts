/**
 * Admin route registration (CWE-287). Every `/admin/*` handler is protected by
 * `requireAuth` followed by `requireRole("admin")`, so the role is always read
 * from the verified session server-side instead of a forgeable header.
 */
import { requireAuth, requireRole } from "../middleware/auth";
import type {
  AuthedRequest,
  AuthHandler,
  AuthResponse,
} from "../middleware/auth";

interface Router {
  use(...handlers: AuthHandler[]): void;
  get(path: string, ...handlers: AuthHandler[]): void;
}

const adminGuard: AuthHandler[] = [requireAuth, requireRole("admin")];

const listUsers: AuthHandler = (req: AuthedRequest, res: AuthResponse) => {
  // `req.user` is guaranteed by the guard chain above.
  res.status(200).json({ actor: req.user?.id, users: [] });
};

const readSettings: AuthHandler = (req: AuthedRequest, res: AuthResponse) => {
  res.status(200).json({ actor: req.user?.id, settings: {} });
};

/** Mounts all admin endpoints behind the auth + role middleware chain. */
export function registerAdminRoutes(router: Router): void {
  router.use(...adminGuard);
  router.get("/admin/users", listUsers);
  router.get("/admin/settings", readSettings);
}

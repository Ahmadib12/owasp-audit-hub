export type Severity = "critical" | "high" | "medium" | "low" | "passed";

export type FindingCategory =
  | "injection"
  | "auth"
  | "cryptography"
  | "misconfig"
  | "ssrf"
  | "xss";

export interface CodeFix {
  vulnerable: string;
  secure: string;
  explanation: string;
}

export interface ReferenceLink {
  label: string;
  url: string;
}

export interface Finding {
  id: string;
  title: string;
  severity: Severity;
  category: FindingCategory;
  cweId: string;
  cweName: string;
  file: string;
  line: number;
  detectedBy: "semgrep" | "bandit" | "manual";
  description: string;
  impact: string;
  remediationSteps: string[];
  code: CodeFix;
  references: ReferenceLink[];
}

export interface ScanStep {
  label: string;
  detail: string;
  done: boolean;
  active: boolean;
}

export type TargetArchetype = "fintech" | "ecommerce" | "legacy" | "generic";

export type GradeTier = "A" | "B" | "C" | "D" | "F";

export interface HeaderCheck {
  name: string;
  passed: boolean;
}

export interface AuditMeta {
  tier: GradeTier;
  archetype: TargetArchetype;
  techStack: string[];
  headerChecks: HeaderCheck[];
  scanMs: number;
  latencyMs: number;
  sslValidThrough: string;
}

export interface AuditResult {
  id: string;
  targetUrl: string;
  scannedAt: string;
  score: number;
  passed: number;
  warnings: number;
  critical: number;
  high: number;
  medium: number;
  low: number;
  avgRemediationDays: number;
  scanOptions: string[];
  findings: Finding[];
  categoryCounts: { category: FindingCategory; count: number }[];
  trend: { label: string; score: number }[];
  compliances: { standard: string; status: boolean; note: string }[];
  meta?: AuditMeta;
}

export interface OwaspItem {
  id: string;
  code: string;
  title: string;
  summary: string;
  attackScenario: string;
  impact: string;
  smeRisk: string;
  checklist: string[];
  remediationTemplate: string;
}

export interface UserProfile {
  name: string;
  email: string;
  role: string;
}

export interface ScanConfig {
  engines: string[];
  maxFindings: number;
  includeArtifacts: boolean;
}

export interface ChartDatum {
  name: string;
  value: number;
  color: string;
}

export interface ScanOption {
  name: string;
  detail: string;
  selected?: boolean;
}

export interface DemoPreset {
  label: string;
  url: string;
  grade: GradeTier;
  hint: string;
}

export const PRESET_TARGETS: DemoPreset[] = [
  {
    label: "Secure Bank Portal",
    url: "https://secure.bank.example.com",
    grade: "A",
    hint: "Fintech-grade hardening, minimal findings",
  },
  {
    label: "E-Commerce API",
    url: "https://shop.example.com",
    grade: "C",
    hint: "Retail stack with cart & CSRF gaps",
  },
  {
    label: "Vulnerable Dev Portal",
    url: "https://dev.admin.example.net",
    grade: "F",
    hint: "Legacy internal tool, critical findings",
  },
  {
    label: "Random SaaS Host",
    url: "https://app.example.io",
    grade: "C",
    hint: "Deterministic hash-derived profile",
  },
];
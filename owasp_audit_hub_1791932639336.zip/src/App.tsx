import { useCallback, useEffect, useMemo, useState } from "react";
import { Toaster, toast } from "sonner";
import { motion } from "framer-motion";
import {
  History,
  LayoutDashboard,
  Printer,
  ShieldCheck,
  Trash2,
  X,
} from "lucide-react";
import Navbar from "./components/Navbar";
import ScanForm from "./components/ScanForm";
import DashboardCharts from "./components/DashboardCharts";
import FindingsList from "./components/FindingsList";
import OwaspEducationModal from "./components/OwaspEducationModal";
import { BRAND_NAME, CATEGORY_META } from "./constants";
import { buildAudit } from "./lib/scannerEngine";
import type {
  AuditResult,
  FindingCategory,
  Severity,
  UserProfile,
} from "./types";

const LS_HISTORY = "cyberaudit_history";
const LS_USER = "cyberaudit_user";
const LS_THEME = "cyberaudit_theme";

function makeAudit(targetUrl: string): AuditResult {
  return buildAudit(targetUrl);
}

export default function App() {
  const [dark, setDark] = useState<boolean>(() => {
    try {
      return localStorage.getItem(LS_THEME) === "dark";
    } catch {
      return true;
    }
  });
  const [user, setUser] = useState<UserProfile | null>(null);
  const [result, setResult] = useState<AuditResult | null>(null);
  const [history, setHistory] = useState<AuditResult[]>([]);
  const [scanning, setScanning] = useState(false);
  const [options, setOptions] = useState<Record<string, boolean>>({
    semgrep: true,
    bandit: true,
    ssl: true,
    headers: true,
  });
  const [severityFilter, setSeverityFilter] = useState<Severity | "all">("all");
  const [authOpen, setAuthOpen] = useState(false);
  const [historyOpen, setHistoryOpen] = useState(false);
  const [owaspOpen, setOwaspOpen] = useState(false);
  const [reportOpen, setReportOpen] = useState(false);
  const [authMode, setAuthMode] = useState<"login" | "register">("login");
  const [authName, setAuthName] = useState("");
  const [authEmail, setAuthEmail] = useState("");
  const [authPass, setAuthPass] = useState("");

  useEffect(() => {
    try {
      const u = localStorage.getItem(LS_USER);
      if (u) setUser(JSON.parse(u));
      const h = localStorage.getItem(LS_HISTORY);
      if (h) setHistory(JSON.parse(h));
    } catch {
      /* corrupted storage */
    }
  }, []);

  useEffect(() => {
    document.documentElement.classList.toggle("dark", dark);
    try {
      localStorage.setItem(LS_THEME, dark ? "dark" : "light");
    } catch {
      /* private mode */
    }
  }, [dark]);

  const persistHistory = useCallback((next: AuditResult[]) => {
    setHistory(next);
    try {
      localStorage.setItem(LS_HISTORY, JSON.stringify(next));
    } catch {
      /* storage full */
    }
  }, []);

  const handleScan = useCallback(
    (url: string) => {
      setScanning(true);
      setResult(null);
      setSeverityFilter("all");
      setTimeout(() => {
        const audit = makeAudit(url);
        const dupIsForSameUrl = history.find(
          (h) => h.targetUrl === url,
        );
        setResult(audit);
        setScanning(false);
        if (dupIsForSameUrl) {
          persistHistory(
            history.map((h) => (h.targetUrl === url ? audit : h)),
          );
        } else {
          persistHistory([audit, ...history]);
        }
        toast.success(`Audit complete for ${url}`);
      }, 4200);
    },
    [history, persistHistory],
  );

  const handleReset = useCallback(() => {
    setScanning(false);
    setResult(null);
    toast("Scan cancelled");
  }, []);

  const toggleOption = useCallback((key: string) => {
    setOptions((o) => ({ ...o, [key]: !o[key] }));
  }, []);

  const handleAuth = useCallback(() => {
    if (!authEmail.includes("@") || authPass.length < 6) {
      toast.error("Enter a valid email and password of at least 6 characters");
      return;
    }
    const profile: UserProfile = {
      name: authMode === "register" && authName.trim()
        ? authName.trim()
        : authEmail.split("@")[0],
      email: authEmail,
      role: authMode === "register" ? "Security Engineer" : "Analyst",
    };
    setUser(profile);
    try {
      localStorage.setItem(LS_USER, JSON.stringify(profile));
    } catch {
      /* storage */
    }
    setAuthOpen(false);
    toast.success(
      authMode === "register" ? "Account created" : "Signed in",
    );
  }, [authMode, authName, authEmail, authPass]);

  const handleLogout = useCallback(() => {
    setUser(null);
    try {
      localStorage.removeItem(LS_USER);
    } catch {
      /* storage */
    }
    toast("Signed out");
  }, []);

  const removeHistory = useCallback(
    (id: string) => {
      persistHistory(history.filter((h) => h.id !== id));
    },
    [history, persistHistory],
  );

  const loadHistoryItem = useCallback((audit: AuditResult) => {
    setResult(audit);
    setHistoryOpen(false);
    toast("Loaded audit snapshot");
  }, []);

  const activeResult = result ?? history[0] ?? null;

  return (
    <div className="min-h-[100dvh] bg-background text-foreground">
      <Navbar
        user={user}
        dark={dark}
        onToggleTheme={() => setDark((d) => !d)}
        onOpenAuth={() => setAuthOpen(true)}
        onOpenHistory={() => setHistoryOpen(true)}
        onOpenOwasp={() => setOwaspOpen(true)}
        onLogout={handleLogout}
        currentTarget={result?.targetUrl ?? ""}
        historyCount={history.length}
      />

      <main className="mx-auto max-w-7xl px-4 pb-24 sm:px-6">
        <section className="py-8">
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4 }}
            className="mx-auto mb-6 max-w-3xl text-center"
          >
            <div className="mb-3 inline-flex items-center gap-1.5 rounded-full border border-emerald-500/30 bg-emerald-500/10 px-3 py-1 text-xs font-medium text-emerald-400">
              <ShieldCheck className="h-3.5 w-3.5" strokeWidth={1.5} />
              Free security audit engine
            </div>
            <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl">
              Scan your web app for vulnerabilities
            </h1>
            <p className="mx-auto mt-2 max-w-xl text-sm text-muted-foreground sm:text-base">
              Run multi-engine SAST and DAST checks, review remediation fixes,
              and export standard artifacts. No signup needed for one scan.
            </p>
          </motion.div>

          <ScanForm
            scanning={scanning}
            options={options}
            onToggleOption={toggleOption}
            onScan={handleScan}
            onReset={handleReset}
          />
        </section>

        {activeResult && (
          <section className="mt-2">
            <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-2">
                <LayoutDashboard className="h-5 w-5 text-emerald-400" strokeWidth={1.5} />
                <h2 className="text-lg font-semibold">Audit dashboard</h2>
                <span className="rounded-full border border-border bg-muted/50 px-2.5 py-0.5 text-xs text-muted-foreground">
                  {activeResult.targetUrl}
                </span>
              </div>
              <div className="flex gap-2">
                <button
                  onClick={() => setReportOpen(true)}
                  className="inline-flex items-center gap-1.5 rounded-lg bg-emerald-500 px-3 py-2 text-xs font-semibold text-emerald-950 transition-colors hover:bg-emerald-400"
                >
                  <Printer className="h-3.5 w-3.5" strokeWidth={1.5} />
                  PDF report
                </button>
              </div>
            </div>

            <DashboardCharts
              result={activeResult}
              severityFilter={severityFilter}
              onFilter={setSeverityFilter}
            />

            <div className="mt-6">
              <h3 className="mb-3 text-lg font-semibold">
                Technical findings
              </h3>
              <FindingsList result={activeResult} />
            </div>
          </section>
        )}

        {!activeResult && !scanning && (
          <section className="mx-auto mt-10 max-w-2xl rounded-2xl border border-dashed border-border px-6 py-12 text-center">
            <p className="text-sm font-medium">No audit results yet</p>
            <p className="mx-auto mt-1 max-w-md text-xs leading-relaxed text-muted-foreground">
              Enter a website URL above and run an audit to generate your
              interactive vulnerability report, severity charts, remediation
              fixes and downloadable SAST / DAST artifacts.
            </p>
          </section>
        )}
      </main>

      {/* Auth modal */}
      {authOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div
            className="absolute inset-0 bg-black/60 backdrop-blur-sm"
            onClick={() => setAuthOpen(false)}
          />
          <motion.div
            initial={{ opacity: 0, scale: 0.96 }}
            animate={{ opacity: 1, scale: 1 }}
            className="relative z-10 w-full max-w-md rounded-2xl border border-border bg-popover p-6 shadow-2xl"
          >
            <div className="mb-4 flex items-center justify-between">
              <h3 className="text-lg font-semibold">
                {authMode === "login" ? "Sign in" : "Create account"}
              </h3>
              <button
                onClick={() => setAuthOpen(false)}
                className="flex h-8 w-8 items-center justify-center rounded-lg text-muted-foreground hover:bg-accent"
              >
                <X className="h-4 w-4" strokeWidth={1.5} />
              </button>
            </div>
            <div className="mb-4 grid grid-cols-2 gap-1 rounded-xl bg-muted p-1">
              {(["login", "register"] as const).map((m) => (
                <button
                  key={m}
                  onClick={() => setAuthMode(m)}
                  className={`rounded-lg py-2 text-sm font-medium transition-colors ${
                    authMode === m
                      ? "bg-card text-foreground shadow-sm"
                      : "text-muted-foreground"
                  }`}
                >
                  {m === "login" ? "Sign in" : "Register"}
                </button>
              ))}
            </div>
            <div className="space-y-3">
              {authMode === "register" && (
                <input
                  value={authName}
                  onChange={(e) => setAuthName(e.target.value)}
                  placeholder="Full name"
                  className="w-full rounded-xl border border-border bg-background px-3 py-2.5 text-sm outline-none focus:ring-2 focus:ring-emerald-500/40"
                />
              )}
              <input
                type="email"
                value={authEmail}
                onChange={(e) => setAuthEmail(e.target.value)}
                placeholder="Email address"
                className="w-full rounded-xl border border-border bg-background px-3 py-2.5 text-sm outline-none focus:ring-2 focus:ring-emerald-500/40"
              />
              <input
                type="password"
                value={authPass}
                onChange={(e) => setAuthPass(e.target.value)}
                placeholder="Password"
                className="w-full rounded-xl border border-border bg-background px-3 py-2.5 text-sm outline-none focus:ring-2 focus:ring-emerald-500/40"
              />
              <button
                onClick={handleAuth}
                className="w-full rounded-xl bg-emerald-500 px-4 py-3 text-sm font-semibold text-emerald-950 transition-colors hover:bg-emerald-400"
              >
                {authMode === "login" ? "Sign in" : "Create account"}
              </button>
              <p className="text-center text-[11px] text-muted-foreground">
                Stored locally in your browser only.
              </p>
            </div>
          </motion.div>
        </div>
      )}

      {/* History drawer */}
      {historyOpen && (
        <div className="fixed inset-0 z-50">
          <div
            className="absolute inset-0 bg-black/60 backdrop-blur-sm"
            onClick={() => setHistoryOpen(false)}
          />
          <div className="absolute right-0 top-0 z-10 flex h-full w-full max-w-md flex-col border-l border-border bg-popover shadow-2xl">
            <div className="flex items-center justify-between border-b border-border p-4">
              <div className="flex items-center gap-2">
                <History className="h-4 w-4 text-emerald-400" strokeWidth={1.5} />
                <p className="text-sm font-semibold">Scan history</p>
              </div>
              <button
                onClick={() => setHistoryOpen(false)}
                className="flex h-8 w-8 items-center justify-center rounded-lg text-muted-foreground hover:bg-accent"
              >
                <X className="h-4 w-4" strokeWidth={1.5} />
              </button>
            </div>
            <div className="flex-1 overflow-y-auto p-4">
              {history.length === 0 ? (
                <p className="py-10 text-center text-sm text-muted-foreground">
                  No scans saved yet.
                </p>
              ) : (
                <div className="space-y-2">
                  {history.map((h) => (
                    <div
                      key={h.id}
                      className="group flex items-center gap-3 rounded-xl border border-border p-3 transition-colors hover:border-emerald-500/40"
                    >
                      <button
                        onClick={() => loadHistoryItem(h)}
                        className="min-w-0 flex-1 text-left"
                      >
                        <p className="truncate text-sm font-medium">{h.targetUrl}</p>
                        <div className="mt-1 flex items-center gap-3 text-xs text-muted-foreground">
                          <span
                            className={
                              h.score >= 80
                                ? "text-emerald-400"
                                : h.score >= 55
                                  ? "text-amber-400"
                                  : "text-rose-400"
                            }
                          >
                            Score {h.score}
                          </span>
                          <span>{new Date(h.scannedAt).toLocaleDateString()}</span>
                          <span>
                            {h.critical + h.high} critical/high
                          </span>
                        </div>
                      </button>
                      <button
                        onClick={() => removeHistory(h.id)}
                        className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg text-muted-foreground opacity-0 transition-all hover:bg-rose-500/10 hover:text-rose-400 group-hover:opacity-100"
                        title="Delete"
                      >
                        <Trash2 className="h-4 w-4" strokeWidth={1.5} />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* OWASP modal */}
      <OwaspEducationModal
        open={owaspOpen}
        onClose={() => setOwaspOpen(false)}
      />

      {/* PDF / print report */}
      {reportOpen && activeResult && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div
            className="absolute inset-0 bg-black/70 backdrop-blur-sm"
            onClick={() => setReportOpen(false)}
          />
          <div className="relative z-10 flex max-h-[92vh] w-full max-w-3xl flex-col overflow-hidden rounded-2xl border border-border bg-popover shadow-2xl">
            <div className="flex items-center justify-between border-b border-border bg-muted/30 px-5 py-3">
              <p className="text-sm font-semibold">Audit report preview</p>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => window.print()}
                  className="inline-flex items-center gap-1.5 rounded-lg bg-emerald-500 px-3 py-2 text-xs font-semibold text-emerald-950 hover:bg-emerald-400"
                >
                  <Printer className="h-3.5 w-3.5" strokeWidth={1.5} />
                  Print / Export PDF
                </button>
                <button
                  onClick={() => setReportOpen(false)}
                  className="flex h-8 w-8 items-center justify-center rounded-lg text-muted-foreground hover:bg-accent"
                >
                  <X className="h-4 w-4" strokeWidth={1.5} />
                </button>
              </div>
            </div>
            <div id="print-report" className="flex-1 overflow-y-auto bg-white p-5 text-zinc-900">
              <PrintReport audit={activeResult} dark={dark} />
            </div>
          </div>
        </div>
      )}

      <Toaster
        position="bottom-right"
        theme={dark ? "dark" : "light"}
        richColors
        closeButton
        toastOptions={{ className: "!text-sm" }}
      />
    </div>
  );
}

function PrintReport({ audit, dark }: { audit: AuditResult; dark: boolean }) {
  const scoreColor =
    audit.score >= 80 ? "#10b981" : audit.score >= 55 ? "#f59e0b" : "#f43f5e";
  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between border-b-2 border-zinc-900 pb-4">
        <div>
          <p className="text-xl font-bold tracking-tight">{BRAND_NAME}</p>
          <p className="text-xs text-zinc-500">Security Audit & Remediation Report</p>
        </div>
        <div className="text-right">
          <p className="text-lg font-bold" style={{ color: scoreColor }}>
            Score {audit.score} / 100
          </p>
          <p className="text-xs text-zinc-500">
            {new Date(audit.scannedAt).toLocaleString()}
          </p>
        </div>
      </div>

      <div>
        <p className="text-xs font-semibold uppercase tracking-wide text-zinc-500">
          Target
        </p>
        <p className="font-mono text-sm">{audit.targetUrl}</p>
      </div>

      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        {[
          { label: "Passed", value: audit.passed, color: "#10b981" },
          { label: "Medium + Low", value: audit.warnings, color: "#f59e0b" },
          { label: "Critical", value: audit.critical, color: "#f43f5e" },
          { label: "High", value: audit.high, color: "#fb923c" },
        ].map((m) => (
          <div key={m.label} className="rounded-lg border border-zinc-200 p-3">
            <p className="text-lg font-bold" style={{ color: m.color }}>
              {m.value}
            </p>
            <p className="text-[11px] text-zinc-500">{m.label}</p>
          </div>
        ))}
      </div>

      <div>
        <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-zinc-500">
          Findings by category
        </p>
        <table className="w-full border-collapse text-left text-xs">
          <thead>
            <tr className="border-b border-zinc-300 text-zinc-500">
              <th className="py-1 pr-2">Category</th>
              <th className="py-1">Count</th>
            </tr>
          </thead>
          <tbody>
            {audit.categoryCounts.map((c) => (
              <tr key={c.category} className="border-b border-zinc-100">
                <td className="py-1 pr-2 capitalize">{CATEGORY_META[c.category]}</td>
                <td className="py-1">{c.count}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div>
        <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-zinc-500">
          Compliance status
        </p>
        <div className="space-y-1.5">
          {audit.compliances.map((c) => (
            <div key={c.standard} className="flex items-center justify-between text-xs">
              <span>{c.standard}</span>
              <span className="text-zinc-500">{c.note}</span>
            </div>
          ))}
        </div>
      </div>

      <div>
        <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-zinc-500">
          Key findings & remediation
        </p>
        <ol className="list-decimal space-y-2 pl-5 text-xs">
          {audit.findings.slice(0, 6).map((f) => (
            <li key={f.id}>
              <span className="font-semibold">
                {f.cweId} {f.title}
              </span>
              <span className="text-zinc-500"> ({f.file}:{f.line})</span>
            </li>
          ))}
        </ol>
      </div>

      <p className="pt-2 text-[10px] text-zinc-400">
        Reports are generated client-side and contain no external data storage.
      </p>
    </div>
  );
}